#ifndef __GLOBAL_H_
#define __GLOBAL_H_

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <memory.h>
#include <vector>
#include "..\common\random.h"


/*------Constants for rnd_uni()--------------------------------------------*/

#define IM1 2147483563
#define IM2 2147483399
#define AM (1.0/IM1)
#define IMM1 (IM1-1)
#define IA1 40014
#define IA2 40692
#define IQ1 53668
#define IQ2 52774
#define IR1 12211
#define IR2 3791
#define NTAB 32
#define NDIV (1+IMM1/NTAB)
#define EPS 1.2e-07
#define RNMX (1.0-EPS)

using namespace std;

#define pi 3.141592653589793238462643383279502884197169399375105

//******** Parameters in test instance *********************************************
int     nvar,      
		nobj;     

int randVal, // save random integer
randVal2;  

int     nvar_l = 10, nvar_u = 20;
int     nobj_l = 2, nobj_u = 2;

double lowBound[50],uppBound[50];

double  CES=1.0E-300;
char    strTestInstance[256];
char    parName[100];

double rnd_uni(long *idum);
double minPeaksOfSDP7(double x, double pt);
double SafeCot(double x);
double SafeAcos(double x);

// *********************************************************************************

//******** Parameters in random number *********************************************
int     seed    = 177;
long    rnd_uni_init; 

double   rnd_rt, 
//Tt,		// time instant;
sdp_y[256]; 

//**********************************************************************************


int		max_gen =300,      
		max_run = 20,      
		pops    = 100,     
		nfes,			   
		itt;              
//**********************************************************************************


int  nt = 10,               
     taut = 10,            
     T0=50;                 

int  Parar=0;              

double Tt=0.0;             

double scale[100];
vector <double> idealpoint;
vector <double> nadirpoint;
vector <double> intercept;

vector <double> normvector; 
char   strFunctionType[256], 
       strAlgorithmType[256]; 
//***************************************************************************************

//******** Parameters in SBX *******************************************************
int		etax    = 20,     
		etam    = 20;

double  realx, realm;      

int     gID;
//**********************************************************************************

//******** Parameters used in Kalman Filter for prediction *************************
double var_process = 0.04; //0.04
double var_measure = 0.01; //0.01
int kalman_order = 3;
int flagcoevo[50];
string str_benchmark;
char parShort[100];
double alpha = 0.0;
double eta_diff = 0.6;
double cetime = 0.0;
vector < double > timere;
int g_run;
double g_time;
double eta = 0.0;
double baifenbi = 0.5;
int test_size = 20;
double proportion = 0.5;
double beta = 0.6;
bool flag_cross = 0; 
#endif