#ifndef __OBJECTIVE_H_
#define __OBJECTIVE_H_

#include "..\common\global.h"

double helper_sum(vector<double> &x, int start, int end, double y)
// including start index wile excluding end index
{
    double s = 0.0;
	int i;
    for (i = start; i < end; i++) s += pow(x[i] - y, 2.0);
    return s;
}
double helper_sum(double *x, int start, int end, double y)
// including start index wile excluding end index
{
    double s = 0.0;
	int i;
    for (i = start; i < end; i++) s += pow(x[i] - y, 2.0);
    return s;
}


//contants for SDP_benchmark  
double SafeAcos(double x)
{
	if (x < -1.0) x = -1.0;
	else if (x > 1.0) x = 1.0;
	return acos(x);
}

double SafeCot(double x)
{
	if (sin(x) == 0)
		return INFINITY;
	else
		return cos(x) / sin(x);
}

double minPeaksOfSDP7(double x, double pt)
{
	if (pt < 1) pt = 1;
	if (pt > 5) pt = 5;
	double min = INFINITY;
	double tmp;
	for (int i = 1; i < 6; i++)
	{
		if (i == pt)
			tmp = 0.5 + 10 * pow(10 * x - 2 * (i - 1), 2.0);
		else
			tmp = i + 10 * pow(10 * x - 2 * (i - 1), 2.0);
		if (tmp <= min)
			min = tmp;
	}
	return min;
}


// the objective vector of SDP.
void objective( vector<double> &x_var, vector<double> &y_obj)
{
	double G = sin(0.5*pi*Tt);
	// SDP PROBLEMS

	if (strcmp(strTestInstance, "SDP1") == 0) //SDP1
	{
		double g = 0;

		// ps functions
		for (int i = nobj; i < nvar; i++)
		{
			g += pow(x_var[i] - sdp_y[i], 2.0);
		}

		// pf functions
		double prd = 1;
		for (int j = 0; j < nobj; j++) {
			//double xx = 3 * x_var[j] + 1; //ԭ���Ĵ��������ά�ȵ�xȡֵ��Χ�޶�Ϊ0��1�����������Ѿ���mylib.h�ļ���ȷ���˶����Ա仯�������Ա�����ȡֵ��Χ
			double xx = x_var[j];  // 1<=Xi=1:m-1<=4
			prd *= xx;
		}
		for (int j = 0; j < nobj; j++)
		{
			//double xx = 3 * x_var[j] + 1;
			double xx = x_var[j];  // 1<=Xi=1:m-1<=4
			y_obj[j] = (1 + g)*xx / pow(prd / xx, 1.0 / (nobj - 1));
		}
		return;
	}

	if (strcmp(strTestInstance, "SDP2") == 0) //SDP2
	{
		double g = 0;

		//double x1 = 3 * x_var[0] + 1;
		double x1 = x_var[0];
		for (int i = nobj - 1; i < nvar; i++)
		{
			//double xx = 2 * (x_var[i] - 0.5) - cos(Tt + 2 * x1);
			double xx = x_var[i] - cos(Tt + 2 * x1); //-1<=Xi=m:n<=1
			g += xx * xx;
		}
		g *= sin(pi*x1 / 8);
		// pf functions
		double sm = 0;
		for (int j = 0; j < nobj - 1; j++)
		{
			//double xx = 3 * x_var[j] + 1; //ԭ���Ĵ��������ά�ȵ�xȡֵ��Χ�޶�Ϊ0��1�����������Ѿ���mylib.h�ļ���ȷ���˶����Ա仯�������Ա�����ȡֵ��Χ
			double xx = x_var[j]; // 1<=Xi=1:m-1<=4
			sm += xx;
		}
		sm += 1;

		for (int j = 0; j < nobj - 1; j++)
		{
			//double xx = 3 * x_var[j] + 1;
			double xx = x_var[j];
			y_obj[j] = (1 + g)*(sm - xx + Tt) / xx;
		}
		y_obj[nobj - 1] = (1 + g)*(sm - 1) / (1 + Tt);
		return;
	}

	if (strcmp(strTestInstance, "SDP3") == 0) //SDP3
	{
		double g = 0;
		int pt = floor(5 * fabs(sin(pi*Tt)));
		for (int i = nobj - 1; i < nvar; i++)
		{
			//double y = 2 * (x_var[i] - 0.5) - cos(Tt);
			double y = x_var[i] - cos(Tt);
			g += 4 * pow(y, 2.0) - cos(2 * pt*pi*y) + 1;
		}

		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			y_obj[j] = (1 + g)*(1 - x_var[j] + 0.05*sin(6 * pi*x_var[j]))*pd;
			pd *= x_var[j] + 0.05*sin(6 * pi*x_var[j]);
		}
		y_obj[nobj - 1] = (1 + g)*pd;
		return;
	}

	if (strcmp(strTestInstance, "SDP4") == 0) //SDP4
	{
		double w = (rnd_rt - 0.5); //----------------------
		if (w > 0)
			w = 1.0;
		else if (w < 0)
			w = -1.0;
		w = w * floor(6 * fabs(G));

		randVal = w; // save this random value

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			//double y = 2 * (x_var[i] - 0.5) - cos(Tt + x_var[i - 1] + x_var[0]);
			double y = x_var[i] - cos(Tt + x_var[i - 1] + x_var[0]);
			g += y * y;
		}

		// pf functions
		double sm = 0;
		for (int j = 0; j < nobj - 2; j++)
		{
			y_obj[j] = x_var[j];
			sm += x_var[j];
		}
		sm += x_var[nobj - 2];
		sm = sm / (nobj - 1);

		y_obj[nobj - 2] = (1 + g)*(sm + 0.05*sin(w*pi*sm));
		y_obj[nobj - 1] = (1 + g)*(1.0 - sm + 0.05*sin(w*pi*sm));
		return;
	}

	if (strcmp(strTestInstance, "SDP5") == 0) //SDP5
	{
		double Gt = fabs(G);
		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			double y = x_var[i] - 0.5*Gt*x_var[0];
			g += y * y;
		}
		g += Gt;

		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			double y = pi * Gt / 6 + (pi / 2 - pi * Gt / 3)*x_var[j];
			y_obj[j] = (1 + g)*sin(y)*pd;
			pd = cos(y)*pd;
		}
		y_obj[nobj - 1] = (1 + g)*pd;
		return;
	}

	if (strcmp(strTestInstance, "SDP6") == 0) //SDP6
	{
		double at = 0.5*fabs(sin(pi*Tt));
		double pt = 10 * cos(2.5*pi*Tt);

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			double y = x_var[i] - 0.5;
			g += y * y *(1 + fabs(cos(8 * pi*x_var[i])));
		}
		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			y_obj[nobj - 1 - j] = (1 + g)*sin(0.5*pi*x_var[j])*pd;
			pd *= cos(0.5*pi*x_var[j]);
		}
		y_obj[0] = (1 + g)*pd;


		if (x_var[0] < at)
			y_obj[nobj - 1] = (1 + g)*fabs(pt*(cos(0.5*pi*x_var[0]) - cos(0.5*pi*at)) + sin(0.5*pi*at));
		//		else
		//            y_obj[nobj - 1] = (1 + g)*sin(0.5*pi*x_var[j])
		return;
	}

	if (strcmp(strTestInstance, "SDP7") == 0) //SDP7
	{
		double at = 0.5*sin(pi*Tt);
		int pt = 1 + floor(5 * rnd_rt);

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			g += minPeaksOfSDP7(x_var[i], pt);
		}
		g /= (nvar - nobj + 1);

		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			y_obj[j] = (0.5 + g)*(1 - x_var[j])*pd;
			pd *= x_var[j];
		}
		y_obj[nobj - 1] = (0.5 + g)*pd;
		return;
	}

	if (strcmp(strTestInstance, "SDP8") == 0) //SDP8
	{
		double kt = 10 * sin(pi*Tt);

		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
			pd *= sin(floor(kt*(2 * x_var[j] - 1.0))*pi / 2);

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			//double y = 2 * (x_var[i] - 0.5) - sin(Tt*x_var[0]);
			double y = x_var[i] - sin(Tt*x_var[0]);
			g += y * y;
		}
		g += fabs(pd);

		// pf functions
		pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			y_obj[nobj - 1 - j] = (1 + g)*sin(0.5*pi*x_var[j])*pd;
			pd *= cos(0.5*pi*x_var[j]);
		}
		y_obj[0] = (1 + g)*pd;
		return;
	}

	if (strcmp(strTestInstance, "SDP9") == 0) //SDP9
	{
		double Gt = fabs(G);
		int pt = floor(6 * Gt);
		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			double y = x_var[i] - fabs(atan(SafeCot(3 * pi*Tt*Tt))) / pi;
			g += y * y;
		}
		g += Gt;

		// pf functions
		double sm = 0;
		for (int j = 0; j < nobj - 1; j++)
		{
			y_obj[j] = (1 + g)*pow(cos(0.5*pi*x_var[j]), 2.0);
			sm += pow(sin(0.5*pi*x_var[j]), 2.0) + sin(0.5*pi*x_var[j])*pow(cos(pt*pi*x_var[j]), 2.0);
		}
		y_obj[nobj - 1] = sm;
		return;
		
		
	}

	if (strcmp(strTestInstance, "SDP10") == 0) //SDP10
	{
		int r = floor(10 * fabs(G));

		double sm = 0;
		for (int j = 0; j < nobj - 1; j++)
			sm += pow(x_var[j], 2.0);
		sm /= (nobj - 1);

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			//double y = 2 * (x_var[i] - 0.5) - sin(0.5*pi*Tt + x_var[0]);
			double y = x_var[i] - sin(0.5*pi*Tt + x_var[0]);
			g += y * y;
		}

		// pf functions
		for (int j = 0; j < nobj - 1; j++)
			y_obj[j] = x_var[j];

		y_obj[nobj - 1] = (1 + g)*(2 - sm - pow(sm, 0.5)*pow(-sin(2.5*pi*sm), r));
		return;
	}

	if (strcmp(strTestInstance, "SDP11") == 0) //SDP11
	{
		double at = 3 * Tt - floor(3 * Tt);
		double bt = 3 * Tt + 0.2 - floor(3 * Tt + 0.2);

		//double sm = 0;
		/*for (int j = 0; j < nobj - 1; j++)
		 sm += x_var[j];
		 sm /= (nobj - 1);*/


		double g = 0;
		double ps = 0;
		for (int i = 0; i < nobj - 1; i++)
			ps += x_var[i];

		if (ps >= at && ps < bt) {
			for (int i = nobj - 1; i < nvar; i++) {
				double p = x_var[i] - fabs(G);
				g += -0.9 * p * p + pow(fabs(p), 0.6);
			}
		}
		else {
			for (int i = nobj - 1; i < nvar; i++) {
				double p = x_var[i] - fabs(G);
				g += p * p;
			}
		}

		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			double yj = 0.5*pi*x_var[j];
			y_obj[j] = (1 + g)*sin(yj)*pd;
			pd *= cos(yj);
		}
		y_obj[nobj - 1] = (1 + g)*pd;
		return;
	}

	if (strcmp(strTestInstance, "SDP12") == 0) //SDP12 -change variables
	{
	

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			//double y = 2 * (x_var[i] - 0.5) - sin(Tt)*sin(2 * pi*x_var[1]);
			double y = x_var[i] - sin(Tt)*sin(2 * pi*x_var[1]);
			g += y * y;
		}

		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			y_obj[j] = (1.0 + g)*(1 - x_var[j])*pd;
			pd *= x_var[j];
		}
		y_obj[nobj - 1] = (1.0 + g)*pd;
		return;
	}

	if (strcmp(strTestInstance, "SDP13") == 0) //SDP13-change objectives
	{
		// *** this is for many objectives only.
		//nobj = nobj_l + floor(rnd_rt*(nobj_u - nobj_l));

		randVal = nobj;  // save this random value.

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			double y = x_var[i] - (i*Tt) / (nobj + i * Tt);
			g += pow(y, 2.0);
		}

		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj; j++)
		{
			double yj = pi * (x_var[j] + 1) / 6;
			y_obj[j] = (1 + g)*sin(yj)*pd;
			pd *= cos(yj);
		}

		for (int j = nobj; j < y_obj.size(); j++)
			y_obj[j] = 0;
		return;
	}

	if (strcmp(strTestInstance, "SDP14") == 0) //SDP14 -degenerate
	{
		double pt = 1 + floor(fabs((nobj - 2)*cos(0.5*pi*Tt)));

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			g += pow(x_var[i] - 0.5, 2.0);
		}


		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			double yj = x_var[j];
			if (j >= pt) yj = 0.5 + x_var[j] * g*fabs(G);
			y_obj[j] = (1 + g)*(1 + g - yj)*pd;
			pd *= yj;
		}
		y_obj[nobj - 1] = (1.0 + g)*pd;
		return;
	}

	if (strcmp(strTestInstance, "SDP15") == 0) //SDP15-degenerate
	{
		int dt = randVal;
		int pt = randVal2;

		double g = 0;
		for (int i = nobj - 1; i < nvar; i++)
		{
			double y = x_var[i] - dt / (nobj - 1);
			g += pow(y, 2.0);
		}

		vector<double> yk(nobj - 1, 0);
		for (int i = 1; i < nobj; i++)
		{
			int k = (pt + i - 1) % (nobj - 1);
			if (k <= dt) yk[k] = 0.5*pi*x_var[k];
			else yk[k] = SafeAcos(1.0 / (pow(2.0, 0.5)*(1.0 + x_var[k] * g*fabs(G))));
		}

		// pf functions
		double pd = 1;
		for (int j = 0; j < nobj - 1; j++)
		{
			y_obj[j] = pow(1 + g, j + 1)*sin(yk[j])*pd;
			pd *= cos(yk[j]);
		}
		y_obj[nobj - 1] = pow(1 + g, nobj)*pd;
		return;
	}

	if (!strcmp(strTestInstance, "DF1"))
	{
		G = fabs(sin(0.5*pi*Tt));
		double H = 0.75*sin(0.5*pi*Tt) + 1.25;
		double g = 1.0 + helper_sum(x_var, 1, nvar, G);

		y_obj[0] = x_var[0];
		y_obj[1] = g * (1 - pow(x_var[0] / g, H));

		return;
	}
	if (!strcmp(strTestInstance, "DF2"))
	{
		int n, r;
		double g = 1.0;
		G = fabs(G);
		if (G < 0.0001)
			r = 0;
		else
			r = floor((nvar - 1) * G);
		for (n = 0; n < nvar; n++)
		{
			if (n != r)
				g += pow(x_var[n] - G, 2.0);
		}

		y_obj[0] = x_var[r];
		y_obj[1] = g * (1 - pow(x_var[r] / g, 0.5));

		return;
	}
	if (!strcmp(strTestInstance, "DF3"))
	{
		double H = G + 1.5;
		double g = 1.0;
		int n;
		for (n = 1; n < nvar; n++)
			g += pow(x_var[n] - G - pow(x_var[0], H), 2.0);
		y_obj[0] = x_var[0];
		y_obj[1] = g * (1 - pow(x_var[0] / g, H));
		return;
	}
	if (!strcmp(strTestInstance, "DF4"))
	{
		int i;
		double a = sin(0.5*pi*Tt);
		double b = 1 + fabs(cos(0.5*pi*Tt));
		double H = 1.5 + a;
		double g = 1.0;
		for (i = 1; i < nvar; i++)
			g += pow(x_var[i] - a * pow(x_var[0], 2) / (i + 1), 2);
		y_obj[0] = g * pow(fabs(x_var[0] - a), H);
		y_obj[1] = g * pow(fabs(x_var[0] - a - b), H);
		return;
	}
	if (!strcmp(strTestInstance, "DF5"))
	{
		if (fabs(G) < 0.0001) G = 0.0;
		int w = floor(10 * G);
		double g = 1.0 + helper_sum(x_var, 1, nvar, G);
		y_obj[0] = g * (x_var[0] + 0.02*sin(w*pi*x_var[0]));
		y_obj[1] = g * (1 - x_var[0] + 0.02*sin(w*pi*x_var[0]));
		return;
	}
	if (!strcmp(strTestInstance, "DF6"))
	{
		double a = 0.2 + 2.8*fabs(G);
		double g = 1.0;
		for (int i = 1; i < nvar; i++)
		{
			double y = x_var[i] - G;
			g += fabs(G)*pow(y, 2.0) - 10.0*cos(2.0*pi*y) + 10.0;
		}
		y_obj[0] = g * pow(x_var[0] + 0.1*sin(3.0*pi*x_var[0]), a);
		y_obj[1] = g * pow(1 - x_var[0] + 0.1*sin(3.0*pi*x_var[0]), a);
		return;
	}

	if (!strcmp(strTestInstance, "DF7"))
	{
		double a = 5.0*cos(0.5*pi*Tt);
		double tmp = 1.0 / (1.0 + exp(a*(x_var[0] - 2.5)));
		double g = 1 + helper_sum(x_var, 1, nvar, tmp);
		y_obj[0] = g * (1.0 + Tt) / x_var[0];
		y_obj[1] = g * x_var[0] / (1.0 + Tt);
		return;
	}
	if (!strcmp(strTestInstance, "DF8"))
	{
		double a = 2.25 + 2.0*cos(2.0*pi*Tt);
		double b = 100.0*pow(G, 2.0);
		double tmp = G * sin(4 * pi*pow(x_var[0], b)) / (1 + fabs(G));
		double g = 1.0 + helper_sum(x_var, 1, nvar, tmp);
		y_obj[0] = g * (x_var[0] + 0.1*sin(3.0*pi*x_var[0]));
		y_obj[1] = g * pow(1.0 - x_var[0] + 0.1*sin(3.0*pi*x_var[0]), a);
		return;
	}
	if (!strcmp(strTestInstance, "DF9"))
	{
		double N = 1.0 + floor(10.0*fabs(sin(0.5*pi*Tt)));
		double g = 1.0;
		for (int i = 1; i < nvar; i++)
		{
			double tmp = x_var[i] - cos(4.0*Tt + x_var[0] + x_var[i - 1]);
			g += pow(tmp, 2.0);
		}
		double temp = (0.1 + 0.5 / N)*sin(2.0*N*pi*x_var[0]);
		if (temp < 0) temp = 0.0;
		y_obj[0] = g * (x_var[0] + temp);
		y_obj[1] = g * (1.0 - x_var[0] + temp);
		return;
	}
	if (!strcmp(strTestInstance, "DF10"))
	{
		double H = 2.25 + 2.0 * cos(0.5 * pi * Tt);
		double tmp = sin(2.0 * pi * (x_var[0] + x_var[1])) / (1.0 + fabs(G));
		double g = 1.0 + helper_sum(x_var, 2, nvar, tmp);
		y_obj[0] = g * pow(sin(0.5 * pi * x_var[0]), H);
		y_obj[1] = g * pow(sin(0.5 * pi * x_var[1]) * cos(0.5 * pi * x_var[0]), H);
		y_obj[2] = g * pow(cos(0.5 * pi * x_var[1]) * cos(0.5 * pi * x_var[0]), H);
		return;
	}
	if (!strcmp(strTestInstance, "DF11"))
	{
		G = fabs(G);
		double g = 1.0 + G + helper_sum(x_var, 2, nvar, 0.5 * G * x_var[0]);
		double y1 = pi * G / 6.0 + (pi / 2.0 - pi * G / 3.0) * x_var[0];
		double y2 = pi * G / 6.0 + (pi / 2.0 - pi * G / 3.0) * x_var[1];
		if (fabs(y1) < 1.0e-10) y1 = 0.0;
		if (fabs(y2) < 1.0e-10) y2 = 0.0;
		y_obj[0] = g * sin(y1);
		y_obj[1] = g * sin(y2) * cos(y1);
		y_obj[2] = g * cos(y2) * cos(y1);
		return;
	}
	if (!strcmp(strTestInstance, "DF12"))
	{
		double k = 10.0 * sin(pi * Tt);
		if (fabs(Tt) < 1.0e-10) k = 0.0;
		double g = 1.0 + helper_sum(x_var, 2, nvar, sin(Tt * x_var[0]));
		double tmp1 = k * (2.0 * x_var[0] - 1.0);
		double tmp2 = k * (2.0 * x_var[1] - 1.0);
		if (fabs(tmp1) < 1.0e-10) tmp1 = 0.0;
		if (fabs(tmp2) < 1.0e-10) tmp2 = 0.0;
		g += fabs(sin(floor(tmp1) * pi / 2.0) * sin(floor(tmp2) * pi / 2.0));
		double tmp3 = 0.5 * pi * x_var[1];
		double tmp4 = 0.5 * pi * x_var[0];
		if (fabs(tmp3) < 1.0e-10) tmp3 = 0.0;
		if (fabs(tmp4) < 1.0e-10) tmp4 = 0.0;
		y_obj[0] = g * cos(tmp3) * cos(tmp4);
		y_obj[1] = g * sin(tmp3) * cos(tmp4);
		y_obj[2] = g * sin(tmp4);
		return;
	}
	if (!strcmp(strTestInstance, "DF13"))
	{
		int p;
		if (fabs(G) < 1e-10)
			p = 0;
		else
			p = floor(6 * G);
		double g = 1.0 + helper_sum(x_var, 2, nvar, G);
		double tmp1 = cos(0.5*pi*x_var[0]);
		double tmp2 = cos(0.5*pi*x_var[1]);
		double tmp3 = sin(0.5*pi*x_var[0]);
		double tmp4 = cos(p*pi*x_var[0]);
		double tmp5 = sin(0.5*pi*x_var[1]);
		double tmp6 = cos(p*pi*x_var[1]);
		if (fabs(tmp1) < 1.0e-10) tmp1 = 0.0;
		if (fabs(tmp2) < 1.0e-10) tmp2 = 0.0;
		if (fabs(tmp3) < 1.0e-10) tmp3 = 0.0;
		if (fabs(tmp4) < 1.0e-10) tmp4 = 0.0;
		if (fabs(tmp5) < 1.0e-10) tmp5 = 0.0;
		if (fabs(tmp6) < 1.0e-10) tmp6 = 0.0;
		y_obj[0] = g * tmp1 * tmp1;
		y_obj[1] = g * tmp2 * tmp2;
		y_obj[2] = g * (tmp3*tmp3 + tmp3 * tmp4*tmp4 + tmp5 * tmp5 + tmp5 * tmp6*tmp6);
		return;
	}
	if (!strcmp(strTestInstance, "DF14"))
	{
		double g = 1.0 + helper_sum(x_var, 2, nvar, G);
		double y = 0.5 + G * (x_var[0] - 0.5);
		double tmp1 = 0.05*sin(6.0*pi*y);
		double tmp2 = 0.05*sin(6.0*pi*x_var[1]);
		if (fabs(tmp1) < 1.0e-10) tmp1 = 0.0;
		if (fabs(tmp2) < 1.0e-10) tmp2 = 0.0;
		y_obj[0] = g * (1.0 - y + tmp1);
		y_obj[1] = g * (1.0 - x_var[1] + tmp2) * (y + tmp1);
		y_obj[2] = g * (x_var[1] + tmp2) * (y + tmp1);
		return;
	}

}



//the random generator in [0,1)
//double rnd_uni(long *idum)
//{
//	long j;
//	long k;
//	static long idum2 = 123456789;
//	static long iy = 0;
//	static long iv[NTAB];
//	double temp;
//
//	if (*idum <= 0)
//	{
//		if (-(*idum) < 1) *idum = 1;
//		else *idum = -(*idum);
//		idum2 = (*idum);
//		for (j = NTAB + 7; j >= 0; j--)
//		{
//			k = (*idum) / IQ1;
//			*idum = IA1 * (*idum - k * IQ1) - k * IR1;
//			if (*idum < 0) *idum += IM1;
//			if (j < NTAB) iv[j] = *idum;
//		}
//		iy = iv[0];
//	}
//	k = (*idum) / IQ1;
//	*idum = IA1 * (*idum - k * IQ1) - k * IR1;
//	if (*idum < 0) *idum += IM1;
//	k = idum2 / IQ2;
//	idum2 = IA2 * (idum2 - k * IQ2) - k * IR2;
//	if (idum2 < 0) idum2 += IM2;
//	j = iy / NDIV;
//	iy = iv[j] - idum2;
//	iv[j] = *idum;
//	if (iy < 1) iy += IMM1;
//	if ((temp = AM * iy) > RNMX) return RNMX;
//	else return temp;
//
//}/*------End of rnd_uni()--------------------------*/
#endif





// dynmaic MOPs
//void objective(vector<double> &x_var, vector<double> &y_obj)
//{
//	double G = sin(0.5*pi*Tt);
//	if (!strcmp(strTestInstance, "FDA1"))
//	{
//		double g = 1.0;
//		int n;
//		for(n = 1; n < nvar; n++)
//			g += pow(x_var[n] - G, 2.0);
//		y_obj[0] = x_var[0];
//		y_obj[1] = g*(1.0 - sqrt(y_obj[0] / g));
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "FDA2"))
//	{
//		double g = 1.0;
//		double H = 0.75 + 0.7 * G;
//		double s = H;
//		int n;
//		for (n = 1; n <= nvar / 2; n++) 
//			g += x_var[n] * x_var[n];		
//		for (n = nvar/2 + 1; n < nvar; n++)
//			s += (x_var[n] - H) * (x_var[n] - H)/(nvar-1.0)*2.0/3.0;//s = s + (x_var[n] - H) * (x_var[n] - H);
//		y_obj[0] = x_var[0];
//		y_obj[1] = g * (1.0 - pow((x_var[0] / g), 1.0 / s));
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "FDA3"))
//	{
//		double g = 1.0, F = pow(10.0, 2.0 * G);
//		int n;
//		for (n = 1; n < nvar; n++)
//			g += (x_var[n] - fabs(G))*(x_var[n] - fabs(G));
//		
//		g += fabs(G);
//
//		y_obj[0] = pow(x_var[0], F);
//		y_obj[1] = g * (1.0 - sqrt(y_obj[0] / g));
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "FDA4"))
//	{
//		double g = 0.0;
//		int i;
//		for(i = 2; i < nvar; i++) g += (x_var[i] - fabs(G)) * (x_var[i] - fabs(G));
//		y_obj[0] = (1.0 + g)*cos(0.5 * pi * x_var[0]) * cos(0.5 * pi * x_var[1]);
//		y_obj[1] = (1.0 + g)*cos(0.5 * pi * x_var[0]) * sin(0.5 * pi * x_var[1]);
//		y_obj[2] = (1.0 + g)*sin(0.5 * pi * x_var[0]);
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "FDA5"))
//	{
//		double g = 0.0, prod;
//		double F = 1.0 + 100.0 * pow(G, 4.0);
//		int i, j, n;
//		for (n = 2; n < nvar; n++)
//			g += pow(x_var[n] - fabs(G), 2.0);
//		g = 1.0 + fabs(G) + g;
//		prod = g;
//		for(n = 0; n < nobj - 1; n++)
//			prod *= cos(0.5*pi*pow(x_var[n], F));
//		y_obj[0] = prod;
//		for(i = 1; i < nobj; i++)
//		{
//			prod = g;
//			for (j = 0; j < nobj - 1 - i; j++)
//				prod *= cos(0.5*pi*pow(x_var[j], F));
//			prod *= sin(0.5*pi*pow(x_var[nobj - 1 - i], F));
//			y_obj[i] = prod;
//		}
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "dMOP1"))
//	{
//		double g = 0.0, H = 0.75 * G + 1.25;
//		int n;
//		for(n = 1; n < nvar; n++)
//			g += pow(x_var[n], 2.0);
//		g = 1.0 + 9.0 * g;
//
//		y_obj[0] = x_var[0];
//		y_obj[1] = g * (1.0 - pow(y_obj[0] / g, H));
//
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "dMOP2"))
//	{
//		double g = 1.0, H = 0.75*G + 1.25;
//		for (int n = 1; n < nvar; n++)
//			g += pow(x_var[n]-fabs(G), 2.0);
//
//		y_obj[0] = x_var[0];
//		y_obj[1] = g*(1.0 - pow(y_obj[0] / g, H));
//
//		return;
//	}
//	
//	if (!strcmp(strTestInstance, "dMOP3"))
//	{
//		double g = 1.0;
//		int n;
//		for(n = 0; n < nvar; n++)
//		{
//			if(n != Parar)
//				g += pow(x_var[n] - G, 2.0);
//		}
//		y_obj[0] = fabs(x_var[Parar]);
//		y_obj[1] = g * (1.0 - sqrt(y_obj[0] / g));
//		
//		return;
//	}
//	if (!strcmp(strTestInstance, "DIMP1")) 
//	{		
//		double g = 1.0;
//		for(int i = 1; i < nvar; i++)
//		{
//			double Gi=sin(0.5*pi*Tt+2.0*pi*((i+1.0)/(nvar+1.0))*((i+1.0)/(nvar+1.0)));
//			g += (x_var[i]-Gi)*(x_var[i]-Gi);
//		}
//		y_obj[0] = x_var[0];
//		y_obj[1] = g*(1.0-(y_obj[0]/g)*(y_obj[0]/g));
//		return;
//	}
//	if (!strcmp(strTestInstance, "DIMP2"))
//	{
//		double g = 1.0 + 2.0 * (nvar - 1.0);
//		double Gi;
//		for (int i = 1; i < nvar; i++)
//		{
//			Gi = sin(0.5*pi*Tt + 2.0 * pi*((i+1.0) / (nvar + 1.0))*((i+1.0) / (nvar + 1.0)));
//			g += (x_var[i] - Gi)*(x_var[i] - Gi) - 2.0 * cos(3.0 * pi * (x_var[i] - Gi));
//		}
//		y_obj[0] = x_var[0];
//		y_obj[1] = g*(1.0 - sqrt(y_obj[0] / g));
//		return;
//	}
//	if (!strcmp(strTestInstance, "JY1")) //JY1
//	{
//		unsigned int j;
//		double a, w, sum1;
//
//		a = 0.05, w = 6.0;
//		sum1 = 0.0;
//		for(j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double yj = x - G;
//			yj = yj*yj;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*(x_var[0] + a*sin(w*pi*x_var[0]));
//		y_obj[1] = (1.0 + sum1)*(1.0 - x_var[0] + a*sin(w*pi*x_var[0]));
//		
//		if(y_obj[0] < 0) y_obj[0] = 0.0;
//		if(y_obj[1] < 0) y_obj[1] = 0.0;
//		return;
//	}
//	if (!strcmp(strTestInstance, "JY2")) //JY2
//	{
//		unsigned int j;
//		double a, w, sum1;
//
//		a = 0.05, w = floor(6 * sin(0.5*pi*(Tt - 1.0)));
//		sum1 = 0.0;
//		for(j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double yj = x - G;
//			yj = yj*yj;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*(x_var[0] + a*sin(w*pi*x_var[0]));
//		y_obj[1] = (1.0 + sum1)*(1.0 - x_var[0] + a*sin(w*pi*x_var[0]));
//		if(y_obj[0] < 0)
//			y_obj[0] = 0.0;
//		if(y_obj[1] < 0)
//			y_obj[1] = 0.0;
//		return;
//	}
//	if (!strcmp(strTestInstance, "JY3")) //JY3
//	{
//		unsigned int j;
//		double a, aa, y1, w, sum1;
//
//		aa = floor(100 * sin(0.5*pi*Tt)*sin(0.5*pi*Tt));
//		y1 = fabs(x_var[0] * sin((2 * aa + 0.5)*pi*x_var[0]));
//
//		a = 0.05, w = floor(6 * sin(0.5*pi*(Tt - 1.0)));
//
//		sum1 = 0.0;
//
//		for (j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double x0 = x_var[j - 1];
//			double yj;
//			if (j == 1){ yj = x*x - y1; }
//			else{ yj = x*x - x0; }
//
//			yj = yj*yj;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*(x_var[0] + a*sin(w*pi*x_var[0]));
//		y_obj[1] = (1.0 + sum1)*(1.0 - x_var[0] + a*sin(w*pi*x_var[0]));
//		if(y_obj[0] < 0)
//			y_obj[0] = 0.0;
//		if(y_obj[1] < 0)
//			y_obj[1] = 0.0;
//		return;
//	}
//	if (!strcmp(strTestInstance, "JY4")) //JY4
//	{
//		unsigned int j;
//		double a, w, g, sum1;
//
//		g = sin(0.5*pi*Tt);
//		a = 0.05, w = pow(10.0, 1.0 + fabs(g));
//
//		sum1 = 0.0;
//
//		for (j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double yj = x - g;
//			yj = yj*yj;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*(x_var[0] + a*sin(w*pi*x_var[0]));
//		y_obj[1] = (1.0 + sum1)*(1.0 - x_var[0] + a*sin(w*pi*x_var[0]));
//		if(y_obj[0] < 0)
//			y_obj[0] = 0.0;
//		if(y_obj[1] < 0)
//			y_obj[1] = 0.0;
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "JY5")) //JY5
//	{
//		unsigned int j;
//		double a, w, g, sum1;
//
//		g = sin(0.5*pi*Tt);
//		a = 0.3*sin(0.5*pi*(Tt - 1.0)), w = 1.0;
//
//		sum1 = 0.0;
//
//		for (j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double yj = x;
//			yj = yj*yj;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*(x_var[0] + a*sin(w*pi*x_var[0]));
//		y_obj[1] = (1.0 + sum1)*(1.0 - x_var[0] + a*sin(w*pi*x_var[0]));
//
//		if(y_obj[0] < 0)
//			y_obj[0] = 0.0;
//		if(y_obj[1] < 0)
//			y_obj[1] = 0.0;
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "JY6")) //JY6
//	{
//		unsigned int j;
//		double a, w, g, k, sum1;
//
//		g = sin(0.5*pi*Tt);
//		a = 0.1, w = 3.0;
//		k = 2.0 * floor(10.0 * fabs(g));
//
//		sum1 = 0.0;
//
//		for (j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double yj = x - g;
//			yj = 4.0 * yj*yj - cos(k*pi*yj) + 1.0;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*(x_var[0] + a*sin(w*pi*x_var[0]));
//		y_obj[1] = (1.0 + sum1)*(1.0 - x_var[0] + a*sin(w*pi*x_var[0]));
//
//		if(y_obj[0] < 0.0)
//			y_obj[0] = 0.0;
//		if(y_obj[1] < 0.0)
//			y_obj[1] = 0.0;
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "JY7")) //JY7
//	{
//		unsigned int j;
//		double a, w, g, s, t, sum1;
//
//		g = sin(0.5*pi*Tt);
//		a = 0.1, w = 3;
//		s = t = 0.2 + 2.8*fabs(g);
//
//		sum1 = 0;
//
//		for (j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double yj = x - g;
//			yj = yj*yj - 10.0 * cos(2.0 * pi*yj) + 10.0;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*pow(x_var[0] + a*sin(w*pi*x_var[0]), s);
//		y_obj[1] = (1.0 + sum1)*pow(1.0 - x_var[0] + a*sin(w*pi*x_var[0]), t);
//
//		if(y_obj[0] < 0.0)
//			y_obj[0] = 0.0;
//		if(y_obj[1] < 0.0)
//			y_obj[1] = 0.0;
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "JY8")) //JY8
//	{
//		unsigned int j;
//		double a, w, g, s, t, sum1;
//
//		g = sin(0.5*pi*Tt);
//		a = 0.05, w = 6.0;
//		t = 10.0 - 9.8*fabs(g);
//		s = 2.0 / t;
//
//		sum1 = 0.0;
//
//		for (j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double yj = x;
//			yj = yj*yj;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*pow(x_var[0] + a*sin(w*pi*x_var[0]), s);
//		y_obj[1] = (1.0 + sum1)*pow(1.0 - x_var[0] + a*sin(w*pi*x_var[0]), t);
//
//
//		if(y_obj[0] < 0.0)
//			y_obj[0] = 0.0;
//		if(y_obj[1] < 0.0)
//			y_obj[1] = 0.0;
//		
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "JY9")) //JY9
//	{
//		unsigned int j, d;
//		double a, w, g, sum1;
//
//		d = (int)floor(Tt * nt / 5.0) % 3;
//		g = fabs(sin(0.5 * pi * Tt));
//		a = 0.05, w = floor(6.0 * pow(sin(0.5 * pi * (Tt - 1.0)), d));
//
//		sum1 = 0.0;
//
//		for (j = 1; j < nvar; j++)
//		{
//			double x = x_var[j];
//			double yj = x + d - g;
//			yj = yj * yj;
//			sum1 += yj;
//		}
//		y_obj[0] = (1.0 + sum1)*(x_var[0] + a*sin(w*pi*x_var[0]));
//		y_obj[1] = (1.0 + sum1)*(1.0 - x_var[0] + a*sin(w*pi*x_var[0]));
//
//		if(y_obj[0] < 0.0)
//			y_obj[0] = 0.0;
//		if(y_obj[1] < 0.0)
//			y_obj[1] = 0.0;
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "ZJZ1")) //F5
//	{
//		int n;
//		double a = 2.0 * cos(pi * Tt) + 2.0;
//		double b = 2.0 * sin(2.0 * pi * Tt) + 2.0;
//		double H = 1.25 + 0.75 * sin(pi * Tt);
//		double Gi;
//		double s1 = 0.0, s2 = 0.0;
//		for(n = 1; n < nvar; n++)
//		{
//			double x = x_var[n];
//			Gi = 1.0 - pow(fabs(x_var[0] - a), H + double(n + 1.0) / double(nvar));
//			if(n % 2)
//				s1 += pow(x - b - Gi, 2.0);
//			else
//				s2 += pow(x - b - Gi, 2.0);
//		}
//		y_obj[0] = pow(fabs(x_var[0] - a), H) + s1;
//		y_obj[1] = pow(fabs(x_var[0] - a - 1.0), H) + s2;
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "ZJZ2")) //F6
//	{
//		int n;
//		double a = 2.0 * cos(1.5*pi*Tt) * sin(0.5*pi*Tt) + 2.0;
//		double b = 2.0 * cos(1.5*pi*Tt) * cos(0.5*pi*Tt) + 2.0;
//		double H = 1.25 + 0.75*sin(pi*Tt);
//		double Gi;
//		double s1 = 0.0, s2 = 0.0;
//		for(n = 1; n < nvar; n++)
//		{
//			double x = x_var[n];
//			Gi = 1.0 - pow(fabs(x_var[0] - a), H + double(n + 1.0) / double(nvar));
//			if (n % 2)
//				s1 += pow(x - b - Gi, 2.0);
//			else
//				s2 += pow(x - b - Gi, 2.0);
//		}
//		y_obj[0] = pow(fabs(x_var[0] - a), H) + s1;
//		y_obj[1] = pow(fabs(x_var[0] - a - 1.0), H) + s2;
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "ZJZ3")) //F7
//	{
//		int n;
//		double a = 1.7 * (1.0 - sin(pi * Tt)) * sin(pi * Tt) + 3.4;
//		double b = 1.4 * (1.0 - sin(pi * Tt)) * cos(pi * Tt) + 2.1;
//		double H = 1.25 + 0.75 * sin(pi * Tt);
//		double Gi;
//		double s1 = 0.0, s2 = 0.0;
//		for (n = 1; n < nvar; n++)
//		{
//			double x = x_var[n];
//			Gi = 1.0 - pow(fabs(x_var[0] - a), H + double(n + 1.0) / double(nvar));
//			if(n % 2)
//				s1 += pow(x - b - Gi, 2.0);
//			else
//				s2 += pow(x - b - Gi, 2.0);
//		}
//		y_obj[0] = pow(fabs(x_var[0] - a), H) + s1;
//		y_obj[1] = pow(fabs(x_var[0] - a - 1.0), H) + s2;
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "ZJZ4")) //F8
//	{
//		int n;
//		double H = 1.25 + 0.75 * sin(pi * Tt);
//		double g = 0.0;
//		for(n = 2; n < nvar; n++)
//		{
//			double x = x_var[n]; 
//			g += pow(x - pow(0.5*(x_var[0] + x_var[1]), H + double(n + 1.0) / double(nvar))-G, 2.0);
//		}
//		y_obj[0] = (1.0 + g)*cos(0.5*pi*x_var[1])*cos(0.5*pi*x_var[0]);
//		y_obj[1] = (1.0 + g)*cos(0.5*pi*x_var[1])*sin(0.5*pi*x_var[0]);
//		y_obj[2] = (1.0 + g)*sin(0.5*pi*x_var[1]);
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "ZJZ5")) //F9
//	{
//		int n;
//		double Tt0 = Tt - floor(Tt);
//		double a = 2.0 * cos(pi*Tt0) + 2.0;
//		double b = 2.0 * sin(2.0*pi*Tt0) + 2.0;
//		double H = 1.25 + 0.75*sin(pi*Tt);
//		double Gi;
//		double s1 = 0.0, s2 = 0.0;
//		for(n = 1; n < nvar; n++)
//		{
//			double x = x_var[n];
//			Gi = 1.0 - pow(fabs(x_var[0] - a), H + double(n + 1.0) / double(nvar));
//			if (n % 2)
//				s1 += pow(x - b - Gi, 2.0);
//			else
//				s2 += pow(x - b - Gi, 2.0);
//		}
//
//		y_obj[0] = pow(fabs(x_var[0] - a), H) + 0.5 * s1;
//		y_obj[1] = pow(fabs(x_var[0] - a - 1.0), H) + 0.5 * s2;
//
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "ZJZ6")) //F10
//	{
//		int n;
//		double a = 2.0 * cos(0.5*pi*Tt) + 2.0;
//		double b = 2.0 * sin(pi*Tt) + 2.0;
//		double H = 1.25 + 0.75*sin(pi*Tt);
//		double Gi;
//		double s1 = 0.0, s2 = 0.0;
//		int old = ((int)(Tt*nt + 0.001)) % 2;
//		for(n = 1; n < nvar; n++)
//		{
//			double x = x_var[n];
//			if(old)
//				Gi = pow(fabs(x_var[0] - a), H + double(n + 1.0) / double(nvar));
//			else 
//				Gi = 1.0 - pow(fabs(x_var[0] - a), H + double(n + 1.0) / double(nvar));
//
//			if(n % 2)
//				s1 += pow(x - b - Gi, 2.0);
//			else
//				s2 += pow(x - b - Gi, 2.0);
//		}
//
//		y_obj[0] = pow(fabs(x_var[0] - a), H) + 0.5 * s1;
//		y_obj[1] = pow(fabs(x_var[0] - a - 1.0), H) + 0.5 * s2;
//
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "Fun7"))
//    {
//		int i;
//		double Gt = sin(Tt * pi / 12.0);
//		double H = 0.75 * sin(0.5 * pi * Tt) + 1.25;
//		double g = 1.0 + H;
//		for(i = 1; i < nvar; i++)
//			g += (x_var[i] - Gt * x_var[0]) * (x_var[i] - Gt * x_var[0]);
//		double h = 1.0 - sqrt(x_var[0] / g);
//        y_obj[0] = x_var[0];
//        y_obj[1] = g * h;
//        return;
//    }
//
//	if (!strcmp(strTestInstance, "Fun8"))
//    {
//		int i;
//		double Gt = sin(Tt * pi / 12.0);
//		double H = 0.7 * sin(0.5 * pi * Tt) + 0.75;
//		double g = 1.0;
//		for(i = 1; i < nvar; i++)
//			g += (x_var[i] - Gt * (x_var[0] - 0.5)) * (x_var[i] - Gt * (x_var[0] - 0.5));
//		double h = 1.0 - pow(x_var[0] / g, 1 / H);
//        y_obj[0] = x_var[0];
//        y_obj[1] = g * h;
//        return;
//    }
//	if (!strcmp(strTestInstance, "Fun9"))
//    {
//		int i;
//		double Gt = sin(Tt * pi / 12.0);
//		double H = sin(0.5 * pi * Tt) + 1.0;
//		double g = 1.0;
//		for(i = 1; i < nvar; i++)
//			g += (x_var[i] - Gt * x_var[0]) * (x_var[i] - Gt * x_var[0]);
//		double h = 1.0 - pow(x_var[0] / g, H);
//        y_obj[0] = x_var[0];
//        y_obj[1] = g * h;
//        return;
//    }
//	if (!strcmp(strTestInstance, "DF1"))
//	{
//		G = fabs(sin(0.5*pi*Tt));
//        double H = 0.75*sin(0.5*pi*Tt)+1.25;
//        double g = 1.0+helper_sum(x_var, 1, nvar, G);
//
//		y_obj[0] = x_var[0];
//		y_obj[1] = g*(1-pow(x_var[0]/g, H));
//
//		return;
//	}
//	if (!strcmp(strTestInstance, "DF2"))
//	{
//		int n, r;
//		double g = 1.0;
//		G = fabs(G);
//		if(G < 0.0001)
//			r = 0;
//		else
//			r = floor((nvar - 1) * G);
//		for(n = 0; n < nvar; n++)
//		{
//			if(n != r)
//				g += pow(x_var[n] - G, 2.0);
//		}
//        
//        y_obj[0] = x_var[r];
//		y_obj[1] = g*(1-pow(x_var[r]/g, 0.5));
//
//		return;
//	}
//	if (!strcmp(strTestInstance, "DF3"))
//	{
//		double H = G+1.5;
//        double g = 1.0;
//		int n;
//		for (n = 1; n < nvar; n++)
//			g += pow(x_var[n] - G - pow(x_var[0], H), 2.0);
//		y_obj[0] = x_var[0];
//		y_obj[1] = g*(1-pow(x_var[0]/g, H));
//		return;
//	}
//	if (!strcmp(strTestInstance, "DF4"))
//	{
//		int i;
//		double a=sin(0.5*pi*Tt);
//        double b=1+fabs(cos(0.5*pi*Tt));
//        double H=1.5+a;
//        double g=1.0;
//        for(i=1; i<nvar; i++)
//            g+=pow(x_var[i]-a*pow(x_var[0],2)/(i+1),2);        
//		y_obj[0] = g*pow(fabs(x_var[0]-a),H);
//		y_obj[1] = g*pow(fabs(x_var[0]-a-b),H);
//		return;
//	}
//	if (!strcmp(strTestInstance, "DF5"))
//	{
//		if(fabs(G) < 0.0001) G = 0.0;
//        int w=floor(10*G);
//        double g=1.0+helper_sum(x_var, 1, nvar, G);
//        y_obj[0]=g*(x_var[0]+0.02*sin(w*pi*x_var[0]));
//        y_obj[1]=g*(1-x_var[0]+0.02*sin(w*pi*x_var[0]));
//		return;
//	}
//	if (!strcmp(strTestInstance, "DF6"))
//	{
//        double a=0.2+2.8*fabs(G);
//        double g=1.0;
//        for (int i=1; i<nvar; i++)
//		{
//            double y=x_var[i]-G;
//            g+=fabs(G)*pow(y,2.0)-10.0*cos(2.0*pi*y)+10.0;
//        }    
//        y_obj[0]=g*pow(x_var[0]+0.1*sin(3.0*pi*x_var[0]),a);
//        y_obj[1]=g*pow(1-x_var[0]+0.1*sin(3.0*pi*x_var[0]),a);
//		return;
//	}
//
//	if (!strcmp(strTestInstance, "DF7"))
//	{
//		double a=5.0*cos(0.5*pi*Tt);
//        double tmp=1.0/(1.0+exp(a*(x_var[0]-2.5)));
//        double g=1+helper_sum(x_var, 1, nvar, tmp);
//        y_obj[0]=g*(1.0+Tt)/x_var[0];
//        y_obj[1]=g*x_var[0]/(1.0+Tt);
//        return;
//	}
//	if (!strcmp(strTestInstance, "DF8"))
//	{
//		double a=2.25+2.0*cos(2.0*pi*Tt);
//		double b=100.0*pow(G,2.0);
//		double tmp=G*sin(4*pi*pow(x_var[0],b))/(1+fabs(G));
//		double g=1.0+helper_sum(x_var, 1, nvar, tmp);
//		y_obj[0]=g*(x_var[0]+0.1*sin(3.0*pi*x_var[0]));
//		y_obj[1]=g*pow(1.0-x_var[0]+0.1*sin(3.0*pi*x_var[0]),a);		
//		return;
//    }
//	if (!strcmp(strTestInstance, "DF9"))
//    {
//        double N=1.0+floor(10.0*fabs(sin(0.5*pi*Tt)));
//        double g=1.0;
//        for (int i=1; i<nvar; i++)
//		{
//            double tmp=x_var[i]-cos(4.0*Tt+x_var[0]+x_var[i-1]);
//            g+=pow(tmp,2.0);
//        }
//		double temp = (0.1+0.5/N)*sin(2.0*N*pi*x_var[0]);
//		if(temp < 0) temp = 0.0;
//        y_obj[0]=g*(x_var[0]+temp);
//        y_obj[1]=g*(1.0-x_var[0]+temp);
//        return;
//    }
//	if (!strcmp(strTestInstance, "DF10"))
//    {
//        double H = 2.25 + 2.0 * cos(0.5 * pi * Tt);
//        double tmp = sin(2.0 * pi * (x_var[0] + x_var[1])) / (1.0 + fabs(G));
//        double g = 1.0 + helper_sum(x_var, 2, nvar, tmp);        
//        y_obj[0] = g * pow(sin(0.5 * pi * x_var[0]), H);
//        y_obj[1] = g * pow(sin(0.5 * pi * x_var[1]) * cos(0.5 * pi * x_var[0]), H);
//        y_obj[2] = g * pow(cos(0.5 * pi * x_var[1]) * cos(0.5 * pi * x_var[0]), H);
//        return;
//    }
//	if (!strcmp(strTestInstance, "DF11"))
//    {
//        G = fabs(G);
//        double g = 1.0 + G + helper_sum(x_var, 2, nvar, 0.5 * G * x_var[0]);
//        double y1 = pi * G / 6.0 + (pi / 2.0 - pi * G / 3.0) * x_var[0];
//        double y2 = pi * G / 6.0 + (pi / 2.0 - pi * G / 3.0) * x_var[1]; 
//		if(fabs(y1) < 1.0e-10) y1 = 0.0;
//		if(fabs(y2) < 1.0e-10) y2 = 0.0;
//        y_obj[0] = g * sin(y1);
//        y_obj[1] = g * sin(y2) * cos(y1);
//        y_obj[2] = g * cos(y2) * cos(y1);
//        return;
//    }
//	if (!strcmp(strTestInstance, "DF12"))
//    {
//        double k = 10.0 * sin(pi * Tt);
//		if(fabs(Tt) < 1.0e-10) k = 0.0;
//        double g = 1.0 + helper_sum(x_var, 2, nvar, sin(Tt * x_var[0]));
//		double tmp1 = k * (2.0 * x_var[0] - 1.0);
//		double tmp2 = k * (2.0 * x_var[1] - 1.0);
//		if(fabs(tmp1) < 1.0e-10) tmp1 = 0.0;
//		if(fabs(tmp2) < 1.0e-10) tmp2 = 0.0;
//        g += fabs(sin(floor(tmp1) * pi / 2.0) * sin(floor(tmp2) * pi / 2.0));
//		double tmp3 = 0.5 * pi * x_var[1];
//		double tmp4 = 0.5 * pi * x_var[0];
//		if(fabs(tmp3) < 1.0e-10) tmp3 = 0.0;
//		if(fabs(tmp4) < 1.0e-10) tmp4 = 0.0;
//        y_obj[0] = g * cos(tmp3) * cos(tmp4);
//        y_obj[1] = g * sin(tmp3) * cos(tmp4);
//		y_obj[2] = g * sin(tmp4);
//        return;
//    }
//	if (!strcmp(strTestInstance, "DF13"))
//    {
//		int p;
//		if(fabs(G) < 1e-10)
//			p = 0;
//		else
//			p = floor(6 * G);
//        double g = 1.0 + helper_sum(x_var, 2, nvar, G);
//		double tmp1 = cos(0.5*pi*x_var[0]);
//		double tmp2 = cos(0.5*pi*x_var[1]);
//		double tmp3 = sin(0.5*pi*x_var[0]);
//		double tmp4 = cos(p*pi*x_var[0]);
//		double tmp5 = sin(0.5*pi*x_var[1]);
//		double tmp6 = cos(p*pi*x_var[1]);
//		if(fabs(tmp1) < 1.0e-10) tmp1 = 0.0;
//		if(fabs(tmp2) < 1.0e-10) tmp2 = 0.0;
//		if(fabs(tmp3) < 1.0e-10) tmp3 = 0.0;
//		if(fabs(tmp4) < 1.0e-10) tmp4 = 0.0;
//		if(fabs(tmp5) < 1.0e-10) tmp5 = 0.0;
//		if(fabs(tmp6) < 1.0e-10) tmp6 = 0.0;
//        y_obj[0]=g * tmp1 * tmp1;
//        y_obj[1]=g * tmp2 * tmp2;
//        y_obj[2]=g*(tmp3*tmp3 + tmp3*tmp4*tmp4 + tmp5*tmp5 + tmp5*tmp6*tmp6);
//        return;
//    }
//    if (!strcmp(strTestInstance, "DF14"))
//    {
//        double g = 1.0 + helper_sum(x_var, 2, nvar, G);
//        double y = 0.5 + G*(x_var[0]-0.5);
//		double tmp1 = 0.05*sin(6.0*pi*y);
//		double tmp2 = 0.05*sin(6.0*pi*x_var[1]);
//		if(fabs(tmp1) < 1.0e-10) tmp1 = 0.0;
//		if(fabs(tmp2) < 1.0e-10) tmp2 = 0.0;
//        y_obj[0]=g * (1.0 - y + tmp1);
//        y_obj[1]=g * (1.0 - x_var[1] + tmp2) * (y + tmp1);
//        y_obj[2]=g * (x_var[1] + tmp2) * (y + tmp1);
//        return;
//    }
//}
//#endif