#ifndef __CPAInd_H_
#define __CPAInd_H_

#include "..\common\global.h"
#include "..\common\objective.h"
#include "..\common\common.h"
#include "PAfunc.h"
#include <string.h>

//test
int PS2line = 0;
//����
class CPAInd{
public:
	CPAInd();
	virtual ~CPAInd();

	vector <double> x_var;
	vector <double> y_obj;

	void   rnd_init();
	void   obj_eval();

    bool   operator<(const CPAInd &ind2);
	bool   operator<<(const CPAInd &ind2);
    bool   operator==(const CPAInd &ind2);
    void   operator=(const CPAInd &ind2);

	int compare(const CPAInd &ind2);
	void show_objective();
	void show_variable();

	int    rank, ncount, rin;
	double fitness;
	vector <double> weight;     // weight vector
	double density;
	
;
};

CPAInd::CPAInd()
{
	for(int i=0; i<nvar; i++)
		x_var.push_back(0.0);
	for(int n=0; n<nobj; n++)
	{
		weight.push_back(0.0);
        y_obj.push_back(0.0);
	}
	rank = 0;
	fitness=0;
	ncount=0;
}

CPAInd::~CPAInd()
{

}

//����PS������
//void CPAInd::rnd_init()
//{
//	//char psfilename[1024];
//	//ps.clear();
//	char str5[100];
//	sprintf(str5, "D:\\��̬��Ŀ��\\���ʦ�ֵ�����\\������ʵPF����\\PF_again\\PF_PS\\SDP3\\��Ŀ��\\");
//	string str6 = "ps_50.txt";
//	string psfilename = str5+str6;
//	cout << psfilename << "\n";
//	char parName3[1024];
//	sprintf(parName3, psfilename.c_str());
//	
//	std::fstream fin;
//	int line = 0;
//	char str[100] = " ";
//	fin.open(parName3, std::ios::in);
//	if (fin.is_open())
//	{
//		const char* pch2;
//		char  a[100], b[100], c[100], d[100], e[100], f[100], g[100], h[100], i[100], j[100];
//		std::string str;
//		while (!fin.eof())
//		{
//			//T  data;
//			std::getline(fin, str, '\n');
//			pch2 = str.c_str();
//			sscanf(pch2, "%s %s %s %s %s %s %s %s %s %s", a, b, c, d, e, f, g, h, i, j);
//			x_var[0] = atof(a);
//			x_var[1] = atof(b);
//			x_var[2] = atof(c);
//			x_var[3] = atof(d);
//			x_var[4] = atof(e);
//			x_var[5] = atof(f);
//			x_var[6] = atof(g);
//			x_var[7] = atof(h);
//			x_var[8] = atof(i);
//			x_var[9] = atof(j);
//			//population.indiv[n];
//
//			if (line == PS2line){
//				PS2line++;
//				line++;
//				break;
//			}
//			line++;
//
//
//			//break;
//			//Tps.push_back(data);
//		}
//		cout << x_var[0] << "  " << x_var[1] << "  " << x_var[2] << endl;
//	} //end if
//	else
//		std::cout << "failed to open " << psfilename << endl;
//	fin.close();
//}


void CPAInd::rnd_init()
{
    for(int n=0;n<nvar;n++)
	{
        x_var[n] = lowBound[n] + rnd_uni(&rnd_uni_init)*(uppBound[n] - lowBound[n]); 
	}
}

void CPAInd::obj_eval()
{
	nfes++;
	objective(x_var, y_obj);
}


void CPAInd::show_objective()
{
    for(int n=0; n<nobj; n++)
		printf("%f ",y_obj[n]);
	printf("\n");
}

void CPAInd::show_variable()
{
    for(int n=0; n<nvar; n++)
		printf("%f ",x_var[n]);
	printf("\n");
}

void CPAInd::operator=(const CPAInd &ind2)
{
    x_var = ind2.x_var;
	y_obj = ind2.y_obj;
	rank  = ind2.rank;
	fitness=ind2.fitness;
	weight =ind2.weight;
	ncount =ind2.ncount;
	rin    =ind2.rin;
}

bool CPAInd::operator<(const CPAInd &ind2)
{
	bool dominated = true;
    for(int n=0; n<nobj; n++)
	{
		if(ind2.y_obj[n]<y_obj[n]) return false;
	}
	if(ind2.y_obj==y_obj) return false;
	return dominated;
}


bool CPAInd::operator<<(const CPAInd &ind2)
{
	bool dominated = true;
    for(int n=0; n<nobj; n++)
	{
		if(ind2.y_obj[n]<y_obj[n]  - 0.0001) return false;
	}
	if(ind2.y_obj==y_obj) return false;
	return dominated;
}

bool CPAInd::operator==(const CPAInd &ind2)
{
	if(ind2.y_obj==y_obj) return true;
	else return false;
}

int CPAInd::compare(const CPAInd &ind2)
{
	// 2: equals ind2
	// 1: dominated by ind2;
	// 0: mutually nondominated;
	//-1: dominate ind2
	int less=0, more=0;
    for(int n=0; n<nobj; n++)
	{
		double a, b;
		a = ind2.y_obj[n];
		b = y_obj[n];
		if(a==b) continue;
		if(a<b) more++;
		if(a>b) less++;
		if(more>0 && less>0) return 0;
	}
	if (more>0 && less==0) return 1;
	if (less>0 && more==0) return -1;
	if (less==0 && more==0) return 2;
	return 0;
}
//��Ⱥ
class CFIN  
{
public:
	CFIN();
	virtual ~CFIN();

	void show();

	CPAInd        indiv;      // best solution
	vector <int>    array;     // neighbourhood table
	vector <double> namda;     // weight vector
	vector <double> ptable;    // probability of selecting a neighbour
	vector <int>    table;     // associated member indices 

	int domc;                  // times dominated by others

	double          density, fitness;

    void  operator=(const CFIN &sub2);
};

CFIN::CFIN()
{
	domc=0;
}

CFIN::~CFIN(){
}

void CFIN::show()
{
   for(int n=0; n<namda.size(); n++){
       printf("%f ",namda[n]);
   }
   printf("\n");
}

void CFIN::operator=(const CFIN &sub2){
    indiv  = sub2.indiv;
    array  = sub2.array;
	table  = sub2.table;
	namda  = sub2.namda;
}

#endif