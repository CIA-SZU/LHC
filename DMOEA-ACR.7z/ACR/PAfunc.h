#ifndef __CPACLASS_H_
#define __CPACLASS_H_

#include "..\common\global.h"
#include "..\common\recombination.h"
#include "..\common\common.h"
#include "PAclass.h"
#include <string.h>
#include "..\common\kalman.h"
#include "direct.h"
class CPA
{
public:
	CPA();
	virtual ~CPA();

	void init_population(); 

	vector <int> rank_pop(vector <CPAInd> &pop); 
	void update_population(CPAInd &indiv); 
	void update_achive(CPAInd &ind); 

	void sbxevolution(); 
	int  tour_selection(); 

	void environmentselection();

	void fill_union(CPAInd &ind);
	vector  <int> truncation(vector <CPAInd> pop, vector <int> v1, int m);
	vector<vector <int> > preservation(vector <CPAInd> &pop, int m);

	int introduce_dynamics(int g);
	bool detect_change(int n);
	void react_change();
	void para_init();

	void execute(int run);

	vector <CFIN>      population;
	vector <CPAInd>   ps;
	vector <CPAInd>   offspring;
	vector <int>       array;
	CPAInd           *ind_arr;

	vector <CPAInd>   Archive;
	vector <CPAInd>   lastArchive;
	int                nondomsize;

	vector<double>  C0, C1, A0, A1;

	int                 popsize;
	void operator=(const CPA &moea);

	vector < KalmanFilter > myFilter;
	double ttest[50];
	double LastDV[50];
	double CurrentDV[50];

	void StaticClassification();
	void SpearmanClassification();

	double distance; 
	void save_front(char savefilename[1024]); 
	void save_ps(char savefilename[1024]);
	void save_Archive(char saveFilename[1024]);
	void save_ArchivePS(char saveFilename[1024]);
	void save_dis(char savefilename[1024]);
	vector<double> igd;
	vector<double> gd;
	vector<double> ms;
	void load_new_PF();
	void calc_igd();
	void calc_ms();
	void calc_gd();
	void save_ALL(char saveFilename[1024]);
	void save_ALL(string saveFilename);
	int n_change;
	vector <CPAInd>   pf;
	vector <CPAInd>     populationSBX;
	vector <CPAInd>     populationDE;
	vector <CFIN>      population_maintain;
	vector <CFIN>      population_predict;
	vector <CFIN>      population_mutation;
	vector <CFIN>      lastPopulation;
	vector <CFIN>      d_x;
	vector <CFIN>      ld_p_ac;
	vector <CFIN>      d_p_ac;

	//new addtion of SDP
	vector <CFIN>      dis0;
	vector <CFIN>      dis1;
	

	void judgecross();
	void ClassificationSO();
	void change_degree();
	void save_pf(char *str);
};

CPA::CPA()
{
	int n;
	ind_arr = new CPAInd[nobj];
	myFilter.resize(nvar);
	// initialize ideal point
	for(n = 0; n < nobj; n++)
	{
		idealpoint.push_back(1.0e+30);
		nadirpoint.push_back(-1.0e+30);
		intercept.push_back(-1.0e+30);
		ind_arr[n].rnd_init();
		ind_arr[n].obj_eval();
	}
}

CPA::~CPA()
{
	idealpoint.clear();
	nadirpoint.clear();
	intercept.clear();
	delete [] ind_arr;
}

void CPA::init_population()
{
	int i;
	PS2line = 0;
	for(i = 0; i < pops; i++)
	{	
		CFIN sub;
		population.push_back(sub);
		population[i].indiv.rnd_init();
		population[i].indiv.obj_eval();
	}	
}

void CPA::operator=(const CPA &alg)
{
	population = alg.population;
	ps         = alg.ps;
	ind_arr    = alg.ind_arr;
	offspring  = alg.offspring;
	popsize    = alg.popsize;
}

void CPA::update_population(CPAInd &indiv)
{
	int k = 0, incomp = 0;
	int i;
	double max = -1.0e+30;
	indiv.ncount = 0;
	for(i = 0; i < pops; i++)
	{
		int dominate = population[i].indiv.compare(indiv);
		switch(dominate)
		{
			case 2: return;
				break;
			case 1: population[i].indiv.ncount++; 
				break;
			case 0: incomp++;
				break;
			case -1: indiv.ncount++;
				break;
			default: break;
		}
		if(max < population[i].indiv.ncount)
		{
			k = i;
			max = population[i].indiv.ncount;
		}
	}

	
	if(max < indiv.ncount) return;

	
	if(incomp == population.size())
		k = int(population.size()*rnd_uni(&rnd_uni_init));

	indiv.fitness = 1.0 * indiv.ncount;
	population[k].indiv = indiv;

	if(indiv.ncount < 1) update_achive(indiv);
}

void CPA::update_achive(CPAInd &ind)
{
	int i;
	int size = Archive.size();
	for(i = 0; i < size; i++)
	{
		int dominate = Archive[i].compare(ind);
		if(dominate == 2 || dominate == -1) break;
		if(dominate == 1)
		{ 
			Archive.erase(Archive.begin() + i); 
			size--;
		}
	}
	Archive.push_back(ind);
}

int  CPA::tour_selection()
{
	int p1 = int(rnd_uni(&rnd_uni_init)*population.size());
	int p2 = int(rnd_uni(&rnd_uni_init)*population.size());
	if(population[p1].indiv.ncount<population[p2].indiv.ncount)
		return p1;
	else
		return p2;
}

vector <int> CPA::rank_pop(vector <CPAInd> &pop)
{
	int i, j;
	
	vector <int> nondom;
	for(i = 0; i < pop.size(); i++)
		pop[i].rank = 0;
	int dominated;
	for(i = 0; i < pop.size(); i++)
	{
		for(j = 0; j < pop.size(); j++)
		{
			dominated = pop[j].compare(pop[i]);
			if(dominated == -1) pop[i].rank++;
		}
	}
	for(i = 0; i < pop.size(); i++) 
	{
		if(pop[i].rank < 1) 
			nondom.push_back(i);
	}
	return nondom;
}

void CPA::environmentselection()
{
	
	int i;
	for(i = 0; i < pops; i++)
		fill_union(population[i].indiv);


	Archive.clear();
	vector< vector< int > > Index;
	Index = preservation(offspring, pops);
	vector< int > eliteIn(Index[0]);
	vector< int > nondomIn(Index[1]);
	nondomsize = nondomIn.size();

	if(nondomsize < pops)
	{
		for(i = 0; i < nondomsize; i++)
			Archive.push_back(offspring[nondomIn[i]]);
		for(i = 0; i < pops; i++)
			population[i].indiv = offspring[eliteIn[i]];
	}

	if(nondomsize == pops)
	{
		for(i = 0; i < pops; i++)
		{
			population[i].indiv=offspring[nondomIn[i]];
			Archive.push_back(offspring[nondomIn[i]]);
		}
	}

	if(nondomsize > pops)
	{
	
		vector < int > trunIn;
		trunIn = truncation(offspring, nondomIn, pops);
		for(i = 0; i < pops; i++)
		{
			population[i].indiv = offspring[trunIn[i]];
			Archive.push_back(offspring[trunIn[i]]);
		}
	}
	offspring.resize(pops);
	for(i = 0; i < pops; i++)
		offspring[i] = population[i].indiv;
	while(offspring.size() > pops) offspring.pop_back();
}

vector <vector <int> > CPA::preservation(vector <CPAInd> &pop, int m)
{
	int i, j;
	int pop_size = pop.size();
	double *fit = new double[pop_size];
	int* idx2 = new int[pop_size];
	vector < int > accept, reject;
	int id = 0;
	for(i = 0; i < pop_size; i++)
	{
		pop[i].ncount = 0;
		double temp_ncount = 0;
		for(j = 0; j < pop_size; j++)
		{
			if(i != j)
			{
				int dominate = pop[i].compare(pop[j]);
				if(dominate == 1)  temp_ncount++;
			}
		}
		pop[i].ncount = temp_ncount;
	}
	
	vector < int > nondomindex;
	for(i = 0; i < pop_size; i++)
	{
		if(pop[i].ncount == 0)
		{
			nondomindex.push_back(i);  
		}
		pop[i].fitness = 1.0 * (pop[i].ncount);  
		fit[i] = pop[i].fitness;
		idx2[i] = i;
	}
	
	minfastsort(fit, idx2, pop_size, m);
	for(i = 0; i < pop_size; i++)
	{
		if(i < m) accept.push_back(idx2[i]);	
	}
	delete [] fit;
	delete [] idx2;
	vector < vector < int > > twovector;
	twovector.push_back(accept);
	twovector.push_back(nondomindex);
	return twovector;
}

vector < int > CPA::truncation(vector < CPAInd > pop, vector < int > v1, int m)
{
	int size = v1.size();
	int i, j, k;
	int **distIndex = new int*[size];
	double **distSort = new double*[size];
	int pop_size = pop.size();
	double **objs = new double*[pop_size];	
	for(i = 0; i < pop_size; i++)
	{
		objs[i] = new double [nobj];
		for(j = 0; j < nobj; j++)
			objs[i][j] = pop[i].y_obj[j];
	}
	int *record = new int [size];
	vector <int> accept;
	double INF = 1.0E+30;
	for(i = 0; i < size; i++)
	{
		record[i] = 1;
		distIndex[i] = new int[size];
		distSort[i] = new double[size];
		for(j = 0; j < i; j++)
		{
			distIndex[i][j] = j;
			double temp = 0.0;
			for(k = 0; k < nobj; k++)
				temp += (objs[v1[i]][k]-objs[v1[j]][k])*(objs[v1[i]][k]-objs[v1[j]][k]);
			distSort[i][j] = sqrt(temp);
			distIndex[j][i] = i;
			distSort[j][i] = distSort[i][j];
		}
		distIndex[i][i] = i;
		distSort[i][i] = INF;
	}
	for(i = 0; i < size; i++)
	{
		minquicksort(distSort[i], distIndex[i], 0, size - 1);
	}
	int cursize = size, mark=0, count;
	double min;
	bool same;
	while(cursize > m)
	{
		min = INF;
		for(i = 0; i < size; i++)
			if(record[i])
			{
				if(min>distSort[i][0])
				{
					min = distSort[i][0];
					mark = i;
				}
				else
				{
					if(min == distSort[i][0])
					{
						same = (pop[v1[i]].y_obj==pop[v1[mark]].y_obj);
						if(same == false)
						{
							count = 0;
							while(distSort[mark][count] == distSort[i][count] && count < cursize - 1) count++;
							if(distSort[mark][count] > distSort[i][count]) mark = i;
						}
					}
				}
			}
		record[mark] = 0;
		for(i = 0; i < size; i++)
		{
			int flag = 0;
			if(record[i])
			{
				for(j = 0; j < cursize; j++)
				{
					if(distIndex[i][j] == mark) flag = 1;
					if(flag)
						if(j < cursize - 1)
						{
							distSort[i][j] = distSort[i][j + 1];
							distIndex[i][j] = distIndex[i][j + 1];
						}
				}
				distSort[i][cursize - 1] = INF;
				distIndex[i][cursize - 1] = mark;
			}
		}
		cursize--;
	}
	for(i = 0; i < size; i++)
	{
		if(record[i]) accept.push_back(v1[i]);
		delete[] distSort[i];
		delete[] distIndex[i];
	}
	delete[] distSort;
	delete[] distIndex;
	delete record;
	for(i = 0; i < pop_size; i++)
		delete[] objs[i];
	delete[] objs;
	return accept;
}

void CPA::fill_union(CPAInd &ind)
{
	int i;
	bool flag = true;
	int  size = offspring.size();
	for(i = 0; i < size; i++)
	{
		if(ind==offspring[i])
		{
			flag = false;
			break;
		}
	}
	if(flag) offspring.push_back(ind);
	
}

void CPA::sbxevolution()
{
	int *perm = new int[pops];
	random_permutation(perm, pops);
	int i, n;
	bool changeIsTrue = false, reactIsTrue=false;

	populationDE.clear();
	populationSBX.clear();
	for(i = 0; i < 0.1*pops; i++)   
	{
		CPAInd child1, child2;
		int p1, p2, p3;
		int dominate;
		double rnd = rnd_uni(&rnd_uni_init);
		if(rnd < 0.5)
		{			
			p1 = (int)(Archive.size())*rnd_uni(&rnd_uni_init);
			while(1)
			{
				p2 = tour_selection();  
				dominate = population[p2].indiv.compare(Archive[p1]);
				if(dominate != 2) break; 
			}
			while(1)
			{
				p3 = tour_selection();
				dominate = Archive[p1].compare(population[p3].indiv);
				if(dominate != 2 && p3 != p2) break;
			}
			real_sbx_xover1(Archive[p1], population[p2].indiv, child1, child2);
			populationSBX.push_back(child1);
			diff_evo_xover2(Archive[p1], population[p2].indiv, population[p3].indiv, child1);
			populationDE.push_back(child1);
		}
		else
		{
			p1 = tour_selection();
			while(1)
			{
				p2 = tour_selection();
				if(p2 != p1) break;
			}
			while(1)
			{
				p3 = tour_selection();
				if(p3 != p1 && p3 != p2) break;
			}
			real_sbx_xover1(population[p1].indiv, population[p2].indiv, child1, child2);
			populationSBX.push_back(child1);
			diff_evo_xover2(population[p1].indiv, population[p2].indiv, population[p3].indiv, child1);
			populationDE.push_back(child1);
		}
	}

	for(i = 0; i < pops; i++)
	{
		n = perm[i];
		if(!changeIsTrue)
			changeIsTrue = detect_change(n);
		if((!reactIsTrue)&&changeIsTrue)
		{
			react_change();
			reactIsTrue = true;
		}
		
		vector<int> p;
		CPAInd child1, child2;
		int p1, p2, p3;
		int dominate;
		double rnd = rnd_uni(&rnd_uni_init);
		if(rnd < 0.5)
		{			
			p1 = (int)(Archive.size())*rnd_uni(&rnd_uni_init);
			while(1)
			{
				p2 = tour_selection();  
				dominate = population[p2].indiv.compare(Archive[p1]);
				if(dominate != 2) break; 
			}
			while(1)
			{
				p3 = tour_selection();
				dominate = Archive[p1].compare(population[p3].indiv);
				if(dominate != 2 && p3 != p2) break;
			}
		
			if (flag_cross) {
				real_sbx_xover1(Archive[p1], population[p2].indiv, child1, child2);
			
			}
			else {
				diff_evo_xover2(Archive[p1], population[p2].indiv, population[p3].indiv, child1);
	
			}
		}
		else
		{
			p1 = tour_selection();
			while(1)
			{
				p2 = tour_selection();
				if(p2 != p1) break;
			}
			while(1)
			{
				p3 = tour_selection();
				if(p3 != p1 && p3 != p2) break;
			}
			if (flag_cross) {
				real_sbx_xover1(population[p1].indiv, population[p2].indiv, child1, child2);
	
			}
			else {
				diff_evo_xover2(population[p1].indiv, population[p2].indiv, population[p3].indiv, child1);
				
			}
		}
		
		realmutation(child1, 1.0 / nvar);
		
		child1.obj_eval();
		update_population(child1);
	}
	changeIsTrue = false;
	delete [] perm;
}

void CPA::StaticClassification()
{
	int i,j;
	int size = Archive.size();

	double ** objs = new double* [nobj];
	for(i = 0; i < nobj; i++)
		objs[i] = new double[size];
	double ** vars = new double* [nvar];
	double **   cc = new double* [nvar];

	for(i = 0; i < nvar; i++)
	{
		vars[i] = new double[size];
		cc[i]   = new double[nobj];
	}

	for(i = 0; i < size; i++)
	{
		for(j = 0; j < nobj; j++)
		{
			objs[j][i] = Archive[i].y_obj[j];
		}
		for(j = 0; j < nvar; j++)
			vars[j][i] = Archive[i].x_var[j];
	}

	for(i = 0; i < nvar; i++)
	{
		for(j = 0; j < nobj; j++)
		{
			cc[i][j] = xiangguanxishu(vars[i], objs[j], size);
		}
	}
	
	for(i = 0; i < nvar; i++)
	{
		vector < double > temp;
		temp = find_Max_Min(cc[i], nobj);
		if(temp[0] - temp[1] > eta_diff)
			flagcoevo[i] = 1;
		else
			flagcoevo[i] = 0;
	}

	for(i = 0; i < nobj; i++)
	{
		delete[] objs[i];
	}
	for(i = 0; i < nvar; i++)
	{
		delete[] vars[i];
		delete[]   cc[i];
	}
	delete[] objs;
	delete[] vars;
	delete[] cc;
}
void CPA::SpearmanClassification()
{
	int i, j, k;
	int size = population.size();
	double **rankx = new double* [nvar];
	double **ranky = new double* [nobj];

	double ** objs = new double* [size];
	double ** vars = new double* [size];
	for(i = 0; i < size; i++)
	{
		objs[i] = new double[nobj];
		vars[i] = new double[nvar];
	}

	for(k = 0; k < nvar; k++)
	{
		rankx[k] = new double [size];
		for(i = 0; i < size; i++)
		{
			rankx[k][i] = size;
			vars[i][k] = population[i].indiv.x_var[k];
		}
	}
	for(k = 0; k < nobj; k++)
	{
		ranky[k] = new double [size];
		for(i = 0; i < size; i++)
		{
			ranky[k][i] = size;
			objs[i][k] = population[i].indiv.y_obj[k];
		}
	}
	
	for(i = 0; i < size; i++)
	{
		for(j = i + 1; j < size; j++)
		{
			for(k = 0; k < nvar; k++)
			{
				if(vars[i][k] == vars[j][k])
					rankx[k][i] -= 0.5, rankx[k][j] -= 0.5;
				else if(vars[i][k] < vars[j][k])
					rankx[k][j]--;
				else
					rankx[k][i]--;
			}
			for(k = 0; k < nobj; k++)
			{
				if(objs[i][k] == objs[j][k])
					ranky[k][i] -= 0.5, ranky[k][j] -= 0.5;
				else if(objs[i][k] < objs[j][k])
					ranky[k][j]--;
				else
					ranky[k][i]--;
			}
		}
	}
	for(i = 0; i < nvar; i++)
	{
		double min = +1.0e+30;
		double max = -1.0e+30;
		for(j = 0; j < nobj; j++)
		{
			double temp = spearman(rankx[i],ranky[j],size);
			if(temp < min) min = temp;
			if(temp > max) max = temp;
		}
		if(max > beta * 0.5 && min < -beta * 0.5)
			flagcoevo[i] = 1;
		else
			flagcoevo[i] = 0;
	}
	for(i = 0; i < nvar; i++)
	{
		delete[] rankx[i];
	}
	for(i = 0; i < nobj; i++)
	{
		delete[] ranky[i];
	}
	delete[] rankx;
	delete[] ranky;
	for(i = 0; i < size; i++)
	{
		delete[] vars[i];
		delete[] objs[i];
	}
	delete[] objs;
	delete[] vars;
}
void CPA::judgecross()
{
	int i, j, k;
	double distanceSBX = 0.0;
	double distanceDE = 0.0;
	int Archive_size = Archive.size();
	int pop_size = populationSBX.size();
	for(i = 0; i < Archive_size; i++)
	{
		double min_dSBX = 1.0e+10;
		double min_dDE = 1.0e+10;
		for(j = 0; j < pop_size; j++)
		{
			double dSBX = 0.0, dDE = 0.0;
			for(k = 0; k < nvar; k++)
			{
				double a, b, c;
				a = Archive[i].x_var[k];
				b = populationSBX[j].x_var[k];
				c = populationDE[j].x_var[k];
				dSBX += (a-b)*(a-b);
				dDE += (a-c)*(a-c);
			}
			dSBX = sqrt(dSBX);
			dDE = sqrt(dDE);
			if(dSBX < min_dSBX) min_dSBX = dSBX;
			if(dDE < min_dDE) min_dDE = dDE;
		}
		distanceSBX += min_dSBX;
		distanceDE += min_dDE;
	}
	if(distanceSBX < distanceDE)
	{
		//proportion = 10.0;
		flag_cross = 0;
	}
	else
	{
		//proportion = -10.0;
		flag_cross = 0;
	}
}

//WTC�������෽��
void CPA::ClassificationSO()
{
	int i, j, k;
	int size = population.size();
	double **rankx = new double*[nvar];
	double **ranky = new double*[nobj];

	double ** objs = new double*[size];
	double ** vars = new double*[size];
	for (i = 0; i < size; i++)
	{
		objs[i] = new double[nobj];
		vars[i] = new double[nvar];
	}

	for (k = 0; k < nvar; k++)
	{
		rankx[k] = new double[size];
		for (i = 0; i < size; i++)
		{
			rankx[k][i] = size;
			vars[i][k] = population[i].indiv.x_var[k];
		}
	}
	for (k = 0; k < nobj; k++)
	{
		ranky[k] = new double[size];
		for (i = 0; i < size; i++)
		{
			ranky[k][i] = size;
			objs[i][k] = population[i].indiv.y_obj[k];
		}
	}

	for (i = 0; i < size; i++)
	{
		for (j = i + 1; j < size; j++)
		{
			for (k = 0; k < nvar; k++)
			{
				if (vars[i][k] == vars[j][k])
					rankx[k][i] -= 0.5, rankx[k][j] -= 0.5;
				else if (vars[i][k] < vars[j][k])
					rankx[k][j]--;
				else
					rankx[k][i]--;
			}
			for (k = 0; k < nobj; k++)
			{
				if (objs[i][k] == objs[j][k])
					ranky[k][i] -= 0.5, ranky[k][j] -= 0.5;
				else if (objs[i][k] < objs[j][k])
					ranky[k][j]--;
				else
					ranky[k][i]--;
			}
		}
	}
	//	cout << itt << "	";
	for (i = 0; i < nvar; i++)
	{
		double min = +1.0e+30;
		double max = -1.0e+30;
		for (j = 0; j < nobj; j++)
		{
			double temp = spearman(rankx[i], ranky[j], size);
			if (temp < min) min = temp;
			if (temp > max) max = temp;
		}
		//printf("%.2lf ", max);
		if (max > beta * 0.5 && min < -beta * 0.5)
			flagcoevo[i] = 1;
		else
			flagcoevo[i] = 0;
	}
	/*cout << itt << "	";
	for(i = 0; i < nvar; i++)
		cout << flagcoevo[i] << " ";*/
		//cout << endl;
	for (i = 0; i < nvar; i++)
	{
		delete[] rankx[i];
	}
	for (i = 0; i < nobj; i++)
	{
		delete[] ranky[i];
	}
	delete[] rankx;
	delete[] ranky;
	for (i = 0; i < size; i++)
	{
		delete[] vars[i];
		delete[] objs[i];
	}
	delete[] objs;
	delete[] vars;
}

void CPA::save_pf(char *saveFilename)
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	/*CNSGA2Ind ind;*/
	for (int n = 0; n < pops; n++)
	{
		for (int k = 0; k < nobj; k++)
		{
			fout << population[n].indiv.y_obj[k];
			k < nobj - 1 ? fout << "," : fout << endl;
		}
	}

	fout.close();
}


void CPA::execute(int run)
{
	para_init();

	seed = (seed + 23)%1377;
	rnd_uni_init = -(long)seed;

	char filename[1024];
	int gen   = 0;
	itt = 0;
	nfes = 0;
	int i;
	init_population();
	environmentselection();

	
	for(gen = 1; gen <= max_gen; gen++)
	{
		
		itt=gen;
		

		char filename[1024];
		char filename1[1024];
		char parName1[100];
		char parName[100];
		char    strTestInstance[256];
		string path = " ";
		_mkdir(path.c_str());

		strcpy_s(strTestInstance, str_benchmark.c_str());
		sprintf_s(parName1, path.append(" ").c_str(), strTestInstance);
		if (_mkdir(parName1))
		
			sprintf_s(parName, " ", parName1, run);
		if (_mkdir(parName))
		
			sprintf_s(filename, " ", parName, gen);

		introduce_dynamics(gen);
		judgecross();
		sbxevolution();
        environmentselection();	
		
		save_pf(filename);
		
		//if((gen - T0 - 1) % taut == 0 && gen >= T0)
		//{
		//	/*if( strcmp(strTestInstance, "FDA1") &&
		//		strcmp(strTestInstance, "FDA4") &&
		//		strcmp(strTestInstance, "dMOP3") &&
		//		strcmp(strTestInstance, "JY1") &&
		//		strcmp(strTestInstance, "JY6") &&
		//		strcmp(strTestInstance, "ZJZ4") &&
		//		strcmp(strTestInstance, "DF2")
		//	  )*/
		//	//load_new_PF();
		//}
		/*if ((gen - T0) % taut == 0 && gen >= T0) {
			load_new_PF();
			calc_igd();
		}*/
	}
	double temp = 0.0;
	double DX = 0.0;
	for(i = 0; i < igd.size(); i++) 
		temp += igd[i];
	temp /= igd.size();
	for (i = 0; i < igd.size(); i++) 
		DX+= (pow((igd[i]-temp),2));
	DX /= igd.size();
	cout << temp << " ";
	cout << DX << " ";

	char parName1[100];
	string path = " ";
	sprintf(parName1,path.append(" ").c_str(),strTestInstance);
	sprintf(filename," ",parName1);
	save_ALL(filename); 

	sprintf(filename," ");
	std::ofstream fout;
	fout.open(filename,std::ios::app);
	


	population.clear();
	igd.clear();
	pf.clear();
}

void CPA::para_init()
{
	Parar = 0;
	Tt = 0.0;
	nfes = 0;
	itt = 0;
}

int CPA::introduce_dynamics(int gen)
{	
	seed = (seed + 23) % 1377;
	rnd_uni_init = -(long)seed;

	

	nobj = nobj_l;
	nvar = nvar_l;

	randVal2 = 0;

	int g = (gen - T0) > 0 ? (gen - T0) : 0;
	
	if (g > 0) {
		Tt = 1.0 / nt * (floor(1.0*(g - 1) / taut) + 1);
		
	}
	else
	{
		Tt = 0.0;
		rnd_rt = 0.0;

	
	}

	if (g%taut == 1)
	{
		rnd_rt = rnd_uni(&rnd_uni_init);

		if ((strTestInstance == "SDP1")) {
			for (int i = nobj - 1; i < nvar; i++)
			{
				rnd_rt = rnd_uni(&rnd_uni_init);
				sdp_y[i] += 5 * (rnd_rt - 0.5)*sin(0.5*pi*Tt);
				if ((sdp_y[i] > 1.0) || (sdp_y[i] < 0.0))
					sdp_y[i] = rnd_rt;
			}
		}

		else if (strTestInstance == "SDP12") {
			nvar = nvar_l + floor(0.5 + rnd_rt * (nvar_u - nvar_l));
			randVal = nvar;
			return nvar;
		}
		else if (strTestInstance == "SDP13") {
			nobj = nobj_l + floor(0.5 + rnd_rt * (nobj_u - nobj_l));
			randVal = nobj;
			return nobj;
		}
		else if (strTestInstance == "SDP15") {
			randVal = 1 + floor(0.5 + rnd_rt * (nobj - 2));
			randVal2 = 1 + floor(0.5 + rnd_uni(&rnd_uni_init)*(nobj - 2));
			return nobj;
		}
	}
	else
	{
		if ((strTestInstance == "SDP1"))
		{
			for (int i = nobj; i < nvar; i++)
			{
				sdp_y[i] = 1.0 * (i + 1) / nvar;
			}
		}

		if ((strTestInstance == "SDP13"))
		{
			nobj = 2;
		}

		if ((strTestInstance == "SDP15"))
		{
			randVal = nobj - 1; randVal2 = 0;
		}

	}
	return 1;

	/*int g = (gen - T0) > 0 ? (gen - T0) : 0;
	if(g > 0)
		Tt = 1.0 / nt*(floor(1.0*(g-1)/ taut) + 1);
	else
		Tt = 0.0;

	if((Tt > 0) && (g % taut == 1))
		if(!strcmp(strTestInstance, "dMOP3"))
		{
			Parar = rand()%nvar;
		}*/
}


bool CPA::detect_change(int n)
{

	int i;
	double *oldobj = new double [nobj];
	for(i = 0; i < nobj; i++)
		oldobj[i] = population[n].indiv.y_obj[i];
	population[n].indiv.obj_eval();
	nfes--;
	double Tolerror = CES;
	for(i = 0; i < nobj; i++)
	{
		if(population[n].indiv.y_obj[i] != oldobj[i])
		{
			return true;
		}
	}
	delete oldobj;
	return false;
}



void CPA::react_change()
{
	int size = population.size();
	int i, j, n;
	double result = 0.0;
	double stepsize;
	double distance_predict = 0.0;
	double distance_mutation = 0.0;
	int bianyi = 0.1;
	double geshu = 1;
	if(C0.size())
	{
		int Archive_size = Archive.size();
		for(i = 0; i < Archive_size; i++)
		{
			double min_predict = 1.0e+10;
			double min_mutation = 1.0e+10;
			for(j = 0; j < pops; j++)
			{
				double d_predict = 0.0;
				double d_mutation = 0.0;
				for(n = 0; n < nvar; n++)
				{
					double a, b, c, d;
					a = Archive[i].x_var[n];
					c = population_predict[j].indiv.x_var[n];
					d = population_mutation[j].indiv.x_var[n];
					d_predict += (a-c)*(a-c);
					d_mutation += (a-d)*(a-d);
				}
				d_predict = sqrt(d_predict);
				d_mutation = sqrt(d_mutation);
				if(d_predict< min_predict) min_predict = d_predict;
				if(d_mutation < min_mutation) min_mutation = d_mutation;
			}
			distance_predict += min_predict;
			distance_mutation += min_mutation;
		}
		
	}


	C1.resize(nvar, 0.0);
	A1.resize(nvar, 0.0);
	int Archive_size = Archive.size();
	for (n = 0; n < nvar; n++)
	{
		A1[n] = 0.0;
		C1[n] = 0.0;
		for (i = 0; i < Archive_size; i++) {
			A1[n] += Archive[i].x_var[n];
		} 
		A1[n] /= Archive_size;
		for (i = 0; i < size; i++) C1[n] += population[i].indiv.x_var[n];
		C1[n] /= size;
	}

	

	vector < double > A2(nvar);
	for (i = 0; i < nvar; i++)
		A2[i] = myFilter[i].predict(A1[i]);



	dis1.resize(size);
	dis0.resize(size);
	dis0 = dis1;
	for (n = 0; n < nvar; n++) {
		for (i = 0; i < size; i++) {
			dis1[i].indiv.x_var[n] = population[i].indiv.x_var[n] - A2[n];  
		}
	}



	std::vector<double> mstd1(nvar);
	for (n = 0; n < nvar; n++) {
		mstd1[n] = 0.0;
		for (i = 0; i < size; i++) {
			mstd1[n] += (population[i].indiv.x_var[n] - A2[n])*(population[i].indiv.x_var[n] - A2[n]);
		}
		mstd1[n] = mstd1[n] / double(size);
	}

	
	


	std::vector<unsigned int> PIndex(size);
	double dismin, disDiff;
	for (i = 0; i < size; i++)
	{
		PIndex[i] = 0; dismin = 1.0E100;
		for (j = 0; j < size; j++)
		{
			disDiff = 0.0;
			for (n = 0; n < nvar; n++) {
				disDiff += (dis1[i].indiv.x_var[n] - dis0[j].indiv.x_var[n]) * (dis1[i].indiv.x_var[n] - dis0[j].indiv.x_var[n]);
			}
			if (disDiff < dismin) {
				dismin = disDiff; PIndex[i] = j;
			}
		}
	}
	
	std::vector<double> mstd(nvar);
	for (n = 0; n < nvar; n++)
	{
		mstd[n] = 0;
		//for(i=0; i<psize; i++) mstd += (mBest0[i][k] - mBest1[PIndex[i]][k] - mu[k])*(mBest0[i][k] - mBest1[PIndex[i]][k] - mu[k]);
		for (i = 0; i < size; i++) {
			mstd[n] += (dis1[i].indiv.x_var[n] - dis0[PIndex[i]].indiv.x_var[n]) * (dis1[i].indiv.x_var[n] - dis0[PIndex[i]].indiv.x_var[n]);
			//mstd[n]+= (dis1[i].indiv.x_var[n] - dis0[i].indiv.x_var[n]) * (dis1[i].indiv.x_var[n] - dis0[i].indiv.x_var[n]);
		}
		mstd[n] = mstd[n] / double(size);
		
	}

	population_maintain.resize(size);
	population_predict.resize(size);
	population_mutation.resize(size);
	lastPopulation.resize(size);
	lastArchive.resize(size);
	d_x.resize(size);
	d_p_ac.resize(size);
	ld_p_ac.resize(size);
	
	std::vector<double> d_ac(nvar);
	
	if (C0.size()) {
		for (n = 0; n < nvar; n++) {
			d_ac[n] = 0.0;
			d_ac[n] = abs(A1[n] - A0[n]);
		}

	}
	
	if (C0.size()) {
		for (int i = 0; i < population.size(); i++) {
			
			for (int n = 0; n < nvar; n++) {
				d_x[i].indiv.x_var[n] = abs(population[i].indiv.x_var[n] - lastPopulation[i].indiv.x_var[n]);
			}
		}
	}
	
	if (C0.size()) {
		for (int i = 0; i < population.size(); i++) {

			for (int n = 0; n < nvar; n++) {

				d_p_ac[i].indiv.x_var[n] = abs(population[i].indiv.x_var[n] - A1[n]);
				ld_p_ac[i].indiv.x_var[n]= abs(lastPopulation[i].indiv.x_var[n] - A0[n]);
			}
		}
		
	}

	for (int i = 0; i < population.size(); i++) {
		lastPopulation[i].indiv.x_var = population[i].indiv.x_var;

	}

	for (int i = 0; i < Archive.size(); i++) {
		lastArchive[i].x_var = Archive[i].x_var;
		
	} 
	
	

	for(i = 0; i < size; i++)  
	{
		population_mutation[i].indiv.x_var = population[i].indiv.x_var;
		realmutation(population_mutation[i].indiv, 1.0 / nvar);
		if(C0.size()) 
		{
			for(n = 0; n < nvar; n++)
			{  
				if (d_x[i].indiv.x_var[n] >= d_ac[n]) {
					double std = sqrt(mstd[n]);
					double temp = population[i].indiv.x_var[n];
					population_predict[i].indiv.x_var[n] = population[i].indiv.x_var[n] + (A1[n] - A0[n]) + rnd_gaussian(&rnd_uni_init, 0, d_p_ac[i].indiv.x_var[n] - ld_p_ac[i].indiv.x_var[n]);
	

					if (population_predict[i].indiv.x_var[n] < lowBound[n])
					{
						population_predict[i].indiv.x_var[n] = lowBound[n];
						population_predict[i].indiv.x_var[n] += rnd_uni(&rnd_uni_init)*(temp - lowBound[n]);
					}

					if (population[i].indiv.x_var[n] > uppBound[n])
					{
						population_predict[i].indiv.x_var[n] = uppBound[n];
						population_predict[i].indiv.x_var[n] -= rnd_uni(&rnd_uni_init)*(uppBound[n] - temp);
					}
				}
				
				else 
				{
					double temp = population_mutation[i].indiv.x_var[n];
					realmutation(population_mutation[i].indiv, 1.0 / nvar);
					if (population_mutation[i].indiv.x_var[n] < lowBound[n])
					{
						population_mutation[i].indiv.x_var[n] = lowBound[n];
						population_mutation[i].indiv.x_var[n] += rnd_uni(&rnd_uni_init)*(temp - lowBound[n]);
					}

					if (population_mutation[i].indiv.x_var[n] > uppBound[n])
					{
						population_mutation[i].indiv.x_var[n] = uppBound[n];
						population_mutation[i].indiv.x_var[n] -= rnd_uni(&rnd_uni_init)*(uppBound[n] - temp);
					}
				}
			}
		}
		else  
		{

			realmutation(population_predict[i].indiv, 1.0 / nvar);
		}		
	}
	Archive.clear(); 
	offspring.clear(); 

	
	vector <int> accept, v2;
	
	int id0, id1, id2, tmp;
	v2.resize(size);
	for(i = 0; i < size; i++)
		v2[i] = i;

	double min0, min1, min2;
	min0 = 1.0e+30, min1 = 1.0e+30, min2 = 1.0e+30;
	for(i = 0; i<size; i++)
	{
		if(min0 > population[i].indiv.y_obj[0]) 
		{
			id0 = i;
			min0 = population[i].indiv.y_obj[0];
		}
		if(min1 > population[i].indiv.y_obj[1])
		{
			id1 = i;
			min1 = population[i].indiv.y_obj[1];
		}
		if(nobj > 2)
		{
			if(min2 > population[i].indiv.y_obj[2])
			{
				id2 = i;
				min2 = population[i].indiv.y_obj[2];
			}
		}
	}

	tmp = v2[id0];
	accept.push_back(v2[id0]);
	v2[id0] = v2[size - accept.size()];
	v2[size - accept.size()] = tmp;

	if(id0 != id1)
	{
		tmp = v2[id1];
		accept.push_back(v2[id1]);
		v2[id1] = v2[size - accept.size()];
		v2[size - accept.size()] = tmp;
	}

	if(nobj > 2)
	{
		if(id0 != id2 && id1 != id2)
		{
			tmp = v2[id2];
			accept.push_back(v2[id2]);
			v2[id2] = v2[size - accept.size()];
			v2[size - accept.size()] = tmp;
		}
	}
	
	vector<int> reject,predict, mark(size, 1);
	if(C0.size()) stepsize = dist_vector(C0, C1);

	for(i = 0; i < accept.size(); i++)
	{
		mark[accept[i]] = 0;
		population[accept[i]].indiv.obj_eval();
		fill_union(population[accept[i]].indiv);
	}

	for(i = 0; i < size; i++)
	{
		if(mark[i])
		{
			reject.push_back(i);
			predict.push_back(i); 
		}
	}
	vector <int> vnondom;
	vnondom = rank_pop(offspring);
	for(i = 0; i < vnondom.size(); i++)
		Archive.push_back(offspring[vnondom[i]]);
	int psize = predict.size();
	

	for(i = 0; i < psize; i++)  
	{
		if(C0.size())
		{
			
			if (i < psize)
			{

				for (n = 0; n < nvar; n++)
				{
					double st = sqrt(mstd[n]); 
					double temp = population[predict[i]].indiv.x_var[n];
					
					population[predict[i]].indiv.x_var[n] += (A1[n] - A0[n]) + rnd_gaussian(&rnd_uni_init, 0, d_p_ac[i].indiv.x_var[n] - ld_p_ac[i].indiv.x_var[n]);
					if (population[predict[i]].indiv.x_var[n] < lowBound[n])
					{
						population[predict[i]].indiv.x_var[n] = lowBound[n];
						population[predict[i]].indiv.x_var[n] += rnd_uni(&rnd_uni_init)*(temp - lowBound[n]);
					}

					if (population[predict[i]].indiv.x_var[n] > uppBound[n])
					{
						population[predict[i]].indiv.x_var[n] = uppBound[n];
						population[predict[i]].indiv.x_var[n] -= rnd_uni(&rnd_uni_init)*(uppBound[n] - temp);
					}
				}
			
			}
			
		}
		else
		{
			realmutation(population[predict[i]].indiv, geshu / nvar, bianyi);
		}
		population[predict[i]].indiv.obj_eval();
		fill_union(population[predict[i]].indiv);
		update_achive(population[predict[i]].indiv);
		
	}
	
	A0 = A1;
	C0 = C1;
	
}

void CPA::save_front(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	int n, k;
	for(n = 0; n < pops; n++)
	{
		for(k = 0; k < nobj; k++)
			fout<<population[n].indiv.y_obj[k]<<"	";
		fout<<"\n";
	}
	fout.close();
}

void CPA::save_Archive(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	int n, k;
	for(n = 0; n < Archive.size(); n++)
	{
		for(k = 0; k < nobj; k++)
			fout << Archive[n].y_obj[k] << "	";
		fout << "\n";
	}
	fout.close();
}

void CPA::save_ps(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename,std::ios::out);
	int n, k;
	for(n = 0; n < pops; n++)
	{
		for(k = 0; k < nvar; k++)
			fout << population[n].indiv.x_var[k] << "	";
		fout << "\n";
	}
	fout.close();
}

void CPA::save_ArchivePS(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename,std::ios::out);
	int n, k;
	for(n = 0; n < Archive.size(); n++)
	{
		for(k = 0; k < nvar; k++)
			fout << Archive[n].x_var[k] << "	";
		fout << "\n";
	}
	fout.close();
}

void CPA::load_new_PF()
{
	pf.clear();
	char str1[50];
	sprintf(str1, " ");
	string str2 = " ";
	string str3 = " ";
	char str[10];
	int g = (itt - T0)>0 ? (itt - T0) : 0;
	//int xx = (floor(1.0*(g - 1) / taut) + 1);
	int xx = 0;
	sprintf(str, "%d", xx);
	
	//string filename = str1 + str_benchmark + str2 + str + str3;
	//if (str_benchmark == "DF10")
		//int lala = 1;
	
	char parName1[1024];

	loadpfront(parName1, pf);
}

void CPA::save_ALL(char saveFilename[1024])
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	int k;
	for(k = 0; k<igd.size(); k++)
	{

		fout << k + 1 << "	" << igd[k] << endl;
	}
	fout.close();
}

void CPA::calc_igd()
{
	int i, j, k;
	double distance = 0.0;
	int pf_size = pf.size();
	for(i = 0; i < pf_size; i++)
	{
		double min_d = 1.0e+10;
		for(j = 0; j < pops; j++)
		{
			double d = 0.0;
			for(k = 0; k < nobj; k++)
			{
				double a, b;
				a = pf[i].y_obj[k];
				b = population[j].indiv.y_obj[k];
				d += (a-b)*(a-b);
			}
			d = sqrt(d);
			if(d < min_d) min_d = d;
		}
		distance += min_d;
	}
	distance /= pf_size;
	igd.push_back(distance);
}

void CPA::calc_gd()
{
	int i, j;
	distance = 0.0;
	for(i = 0; i<population.size(); i++)
	{
		double min_d = 1.0e+10;
		for(j = 0; j<pf.size(); j++)
		{
			double d = dist_vector(pf[j].y_obj, population[i].indiv.y_obj);
			if(d<min_d) min_d = d;
		}
		distance += min_d;
	}
	distance /= population.size();
	gd.push_back(distance);
}

void CPA::calc_ms()
{
	double spread = 0.0, s, F_max, F_min, f_max, f_min;
	int i, k;
	for(k = 0; k < nobj; k++)
	{
		s = 0.0;
		F_max = -1.0e+10;
		F_min = +1.0e+10;
		f_max = -1.0e+10;
		f_min = +1.0e+10;
		for(i = 0; i < pf.size(); i++)
		{
			F_max = pf[i].y_obj[k] > F_max ? pf[i].y_obj[k] : F_max;
			F_min = pf[i].y_obj[k] < F_min ? pf[i].y_obj[k] : F_min;
		}
		for(i = 0; i < pops; i++)
		{
			CPAInd PF_i = population[i].indiv;
			f_max = PF_i.y_obj[k] > f_max ? PF_i.y_obj[k] : f_max;
			f_min = PF_i.y_obj[k] < f_min ? PF_i.y_obj[k] : f_min;
		}
		s = f_max < F_max ? f_max : F_max;
		s -= f_min > F_min ? f_min : F_min;
		s /= (F_max - F_min);
		spread += s*s;
	}
	spread = sqrt(spread / nobj);
	ms.push_back(spread);
}
#endif