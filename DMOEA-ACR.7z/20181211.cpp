#include "common\global.h"
#include "PA\PAfunc.h"
#include <time.h>
void execute();

void main()
{
	
	char *ins[] = {

		//   0       1      2      3      4      5       6       7       8       9
		"SDP1",  "SDP2", "SDP3", "SDP4","SDP5", "SDP6", "SDP7","SDP8","SDP9","SDP10",
		//   10      11     12     13     14       15     16     17      18    19     20       21
		"SDP11","SDP12" ,"SDP13","SDP14","SDP15","DF1"  ,"DF2" ,"DF3" ,"DF4" ,"DF5" ,"DF6"  ,"DF7"  ,
	   //   22      23       24     25       26    27      28
		"DF8"  ,"DF9"  ,"DF10" ,"DF11" ,"DF12","DF13","DF14"
	     
		

	 //   //   0       1      2      3      4      5       6       7       8       9
		//"FDA1" ,"FDA2","FDA3","FDA4","FDA5","dMOP1","dMOP2","dMOP3","DIMP1","DIMP2",
	 //   //   10      11     12     13     14     15      16      17      18      19
		//"JY1"  ,"JY2" ,"JY3" ,"JY4" ,"JY5" ,"JY6"  ,"JY7"  ,"JY8"  ,"JY9"  ,"JY10" ,
	 //   //   20      21     22     23     24     25      26      27      28      29
		//"DF1"  ,"DF2" ,"DF3" ,"DF4" ,"DF5" ,"DF6"  ,"DF7"  ,"DF8"  ,"DF9"  ,"DF10" ,
	 //   //   30      31     32     33     34     35      36      37      38      39
		//"DF11" ,"DF12","DF13","DF14","ZJZ1","ZJZ2" ,"ZJZ3" ,"ZJZ4" ,"ZJZ5"  ,"ZJZ6" ,
	 //   //   40      41     42
		// "Fun7","Fun8","Fun9"
	};
	
	int i = 20;
	seed = 177;
	taut = 10;
	max_run = 1;
	for(taut = 10; taut <= 10; taut=taut*2)
	{
		max_gen = T0 + 3 * nt*taut; 
		//max_gen = T0 + 10 * nt*taut; 
		//max_gen = 1;
		for (i = 0; i <=0; i++)
		{
			//if(i == 19) i++;
			
			strcpy(strTestInstance,ins[i]);
			set_bound_nvar_nobj_pops();
			str_benchmark = ins[i];
			execute();
			
		}
	}
	
}

void execute()
{   
	clock_t now, later;
	double passed = 0.0;
	//char timeName[30];
	//FILE *timeFile;

	//sprintf(timeName, "%s_times.txt", str_benchmark);
	//timeFile = fopen(timeName, "w");
	string timeFile = str_benchmark  + " ";
	std::fstream fout;
	fout.open(timeFile, std::ios::out);

	int run;
	for(run=1; run<=max_run; run++) 
	{
		clock_t now, later;                              
		double passed = 0.0;                             
		now = clock();                                  
		CPA PA;
		PA.execute(run);
		if (run == 1) {
			later = clock();
			passed = (later - now) / (double)CLOCKS_PER_SEC;
			//fprintf(timeFile, "%lf\n", passed);
			fout << passed << std::endl;
			
		}
		
	}
}